--
-- PostgreSQL database dump
--

\restrict cXnHJkyeAKio3TaT2t88O2NbsmJztpB2JgeMj4fqRlhlzJkogRQ73OZi840tqhE

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10 (Ubuntu 17.10-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS "pgrst_drop_watch";
DROP EVENT TRIGGER IF EXISTS "pgrst_ddl_watch";
DROP EVENT TRIGGER IF EXISTS "issue_pg_net_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_graphql_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_cron_access";
DROP EVENT TRIGGER IF EXISTS "issue_graphql_placeholder";
DROP PUBLICATION IF EXISTS "supabase_realtime_messages_publication";
DROP PUBLICATION IF EXISTS "supabase_realtime";
DROP POLICY IF EXISTS "Enable read access for all users" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Chỉ cho phép xóa khi đã đăng nhập" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "Chỉ cho phép thêm khi đã đăng nhập" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "Cho phép đọc dữ liệu công khai" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "Cho phép đọc công khai bảng namhoc" ON "public"."namhoc";
DROP POLICY IF EXISTS "Cho phép xóa thông báo" ON "public"."thongbao_riengbiet";
DROP POLICY IF EXISTS "Cho phép tất cả người dùng đọc thông báo" ON "public"."thongbao_riengbiet";
DROP POLICY IF EXISTS "Cho phép thêm thông báo" ON "public"."thongbao_riengbiet";
DROP POLICY IF EXISTS "Cho phép người dùng đã đăng nhập thao tác github_se" ON "public"."github_settings";
DROP POLICY IF EXISTS "Cho phép người dùng xác thực có toàn quyền bảng n" ON "public"."namhoc";
DROP POLICY IF EXISTS "Cho phép cập nhật thông báo" ON "public"."thongbao_riengbiet";
DROP POLICY IF EXISTS "Cho phép cập nhật dữ liệu công khai" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "Cho phép UPDATE thongbao_hethong khi đã đăng nhập" ON "public"."thongbao_hethong";
DROP POLICY IF EXISTS "Cho phép UPDATE push_subscriptions khi đã đăng nhập" ON "public"."push_subscriptions";
DROP POLICY IF EXISTS "Cho phép SELECT thongbao_hethong khi đã đăng nhập" ON "public"."thongbao_hethong";
DROP POLICY IF EXISTS "Cho phép SELECT push_subscriptions khi đã đăng nhập" ON "public"."push_subscriptions";
DROP POLICY IF EXISTS "Cho phép INSERT thongbao_hethong khi đã đăng nhập" ON "public"."thongbao_hethong";
DROP POLICY IF EXISTS "Cho phép INSERT push_subscriptions khi đã đăng nhập" ON "public"."push_subscriptions";
DROP POLICY IF EXISTS "Cho phép DELETE thongbao_hethong khi đã đăng nhập" ON "public"."thongbao_hethong";
DROP POLICY IF EXISTS "Cho phép DELETE push_subscriptions khi đã đăng nhập" ON "public"."push_subscriptions";
DROP POLICY IF EXISTS "Cho phép Admin quản lý cấu hình github" ON "public"."github_settings";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."settings";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."ptdoanvien";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."phanquyen";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."phancong";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."namhoc";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."dotptdoanvien";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."doanvien";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."chamdiem";
DROP POLICY IF EXISTS "Authenticated users can insert activity logs" ON "public"."activity_logs";
DROP POLICY IF EXISTS "Allow full access for authenticated users on ql_nop_bc" ON "public"."ql_nop_bc";
DROP POLICY IF EXISTS "Allow full access for authenticated users" ON "public"."ql_baocao";
DROP POLICY IF EXISTS "Allow authenticated users to UPDATE" ON "public"."theodoi360";
DROP POLICY IF EXISTS "Allow authenticated users to SELECT" ON "public"."theodoi360";
DROP POLICY IF EXISTS "Allow authenticated users to INSERT" ON "public"."theodoi360";
DROP POLICY IF EXISTS "Allow authenticated users to DELETE" ON "public"."theodoi360";
DROP POLICY IF EXISTS "Admins can view all activity logs" ON "public"."activity_logs";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_upload_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_bucketId_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_tuan_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_tieu_chi_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_nguoi_to_cao_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_nam_hoc_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_doan_vien_vi_pham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_doanvien_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "fk_tuanhoc_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "fk_tieuchitd_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "fk_settings_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "fk_qlchidoan_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "fk_ql_nop_bc_doanvien";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "fk_ql_nop_bc_chidoan";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "fk_ql_nop_bc_baocao";
ALTER TABLE IF EXISTS ONLY "public"."ql_baocao" DROP CONSTRAINT IF EXISTS "fk_ql_baocao_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "fk_ptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "fk_phanquyen_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "fk_phancong_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "fk_dotptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "fk_doanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "fk_chamdiem_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_doanvienid_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_namhoc_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_dotdangki_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_doanvien_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_oauth_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_flow_state_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_auth_factor_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_user_id_fkey";
DROP TRIGGER IF EXISTS "update_objects_updated_at" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_objects_delete" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_buckets_delete" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "enforce_bucket_name_length_trigger" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "tr_check_filters" ON "realtime"."subscription";
DROP TRIGGER IF EXISTS "update_tuanhoc_modtime" ON "public"."tuanhoc";
DROP TRIGGER IF EXISTS "update_tieuchitd_modtime" ON "public"."tieuchitd";
DROP TRIGGER IF EXISTS "update_taikhoan_modtime" ON "public"."taikhoan";
DROP TRIGGER IF EXISTS "update_settings_modtime" ON "public"."settings";
DROP TRIGGER IF EXISTS "update_qlchidoan_modtime" ON "public"."qlchidoan";
DROP TRIGGER IF EXISTS "update_ptdoanvien_modtime" ON "public"."ptdoanvien";
DROP TRIGGER IF EXISTS "update_phanquyen_modtime" ON "public"."phanquyen";
DROP TRIGGER IF EXISTS "update_phancong_modtime" ON "public"."phancong";
DROP TRIGGER IF EXISTS "update_namhoc_modtime" ON "public"."namhoc";
DROP TRIGGER IF EXISTS "update_github_settings_modtime" ON "public"."github_settings";
DROP TRIGGER IF EXISTS "update_duytricsdl_modtime" ON "public"."duytricsdl";
DROP TRIGGER IF EXISTS "update_dotptdoanvien_modtime" ON "public"."dotptdoanvien";
DROP TRIGGER IF EXISTS "update_doanvien_modtime" ON "public"."doanvien";
DROP TRIGGER IF EXISTS "update_chamdiem_modtime" ON "public"."chamdiem";
DROP TRIGGER IF EXISTS "trigger_chi_doan_deletion" ON "public"."qlchidoan";
DROP INDEX IF EXISTS "storage"."vector_indexes_name_bucket_id_idx";
DROP INDEX IF EXISTS "storage"."name_prefix_search";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name_lower";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name";
DROP INDEX IF EXISTS "storage"."idx_multipart_uploads_list";
DROP INDEX IF EXISTS "storage"."buckets_analytics_unique_name_idx";
DROP INDEX IF EXISTS "storage"."bucketid_objname";
DROP INDEX IF EXISTS "storage"."bname";
DROP INDEX IF EXISTS "realtime"."subscription_subscription_id_entity_filters_action_filter_selec";
DROP INDEX IF EXISTS "realtime"."messages_inserted_at_topic_index";
DROP INDEX IF EXISTS "realtime"."ix_realtime_subscription_entity";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_dotdangki";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_optimization_namhoc_hocky";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_context";
DROP INDEX IF EXISTS "public"."idx_tuan_isdefault_true";
DROP INDEX IF EXISTS "public"."idx_tieuchitd_context";
DROP INDEX IF EXISTS "public"."idx_theodoi360_namhoc_tuan";
DROP INDEX IF EXISTS "public"."idx_theodoi360_doanvien";
DROP INDEX IF EXISTS "public"."idx_taikhoan_username_lower";
DROP INDEX IF EXISTS "public"."idx_taikhoan_role";
DROP INDEX IF EXISTS "public"."idx_taikhoan_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_settings_namhoc";
DROP INDEX IF EXISTS "public"."idx_qlchidoan_optimization_namhoc";
DROP INDEX IF EXISTS "public"."idx_ql_nop_bc_doanvien";
DROP INDEX IF EXISTS "public"."idx_ql_nop_bc_chidoan";
DROP INDEX IF EXISTS "public"."idx_ql_nop_bc_baocao";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_dotdangki";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_dot";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_doanvien";
DROP INDEX IF EXISTS "public"."idx_phanquyen_namhoc";
DROP INDEX IF EXISTS "public"."idx_phancong_lopcham";
DROP INDEX IF EXISTS "public"."idx_phancong_context";
DROP INDEX IF EXISTS "public"."idx_phancong_chamlop";
DROP INDEX IF EXISTS "public"."idx_namhoc_isdefault_true";
DROP INDEX IF EXISTS "public"."idx_dotptdoanvien_nam_hk";
DROP INDEX IF EXISTS "public"."idx_doanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_doanvien_hoten";
DROP INDEX IF EXISTS "public"."idx_doanvien_chidoan_namhoc";
DROP INDEX IF EXISTS "public"."idx_chamdiem_thongke";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_namhoc_tuan";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_namhoc_hocky_tuan";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_chamlop";
DROP INDEX IF EXISTS "public"."idx_chamdiem_lopcham_chamlop";
DROP INDEX IF EXISTS "public"."idx_chamdiem_loaitieuchi";
DROP INDEX IF EXISTS "public"."idx_chamdiem_hocky";
DROP INDEX IF EXISTS "public"."idx_chamdiem_doanvienid";
DROP INDEX IF EXISTS "public"."idx_chamdiem_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_chamdiem_chamlop";
DROP INDEX IF EXISTS "public"."idx_activity_logs_user_id";
DROP INDEX IF EXISTS "public"."idx_activity_logs_created_at";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_credential_id_key";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_expires_at_idx";
DROP INDEX IF EXISTS "auth"."users_is_anonymous_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_email_idx";
DROP INDEX IF EXISTS "auth"."users_email_partial_key";
DROP INDEX IF EXISTS "auth"."user_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."unique_phone_factor_per_user";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_pattern_idx";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_domain_idx";
DROP INDEX IF EXISTS "auth"."sessions_user_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_oauth_client_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_not_after_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_for_email_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_created_at_idx";
DROP INDEX IF EXISTS "auth"."saml_providers_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_updated_at_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_session_id_revoked_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_parent_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_user_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_idx";
DROP INDEX IF EXISTS "auth"."recovery_token_idx";
DROP INDEX IF EXISTS "auth"."reauthentication_token_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_user_id_token_type_key";
DROP INDEX IF EXISTS "auth"."one_time_tokens_token_hash_hash_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_relates_to_hash_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_user_order_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_user_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_clients_deleted_at_idx";
DROP INDEX IF EXISTS "auth"."oauth_auth_pending_exp_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_id_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_friendly_name_unique";
DROP INDEX IF EXISTS "auth"."mfa_challenge_created_at_idx";
DROP INDEX IF EXISTS "auth"."idx_users_name";
DROP INDEX IF EXISTS "auth"."idx_users_last_sign_in_at_desc";
DROP INDEX IF EXISTS "auth"."idx_users_email";
DROP INDEX IF EXISTS "auth"."idx_users_created_at_desc";
DROP INDEX IF EXISTS "auth"."idx_user_id_auth_method";
DROP INDEX IF EXISTS "auth"."idx_oauth_client_states_created_at";
DROP INDEX IF EXISTS "auth"."idx_auth_code";
DROP INDEX IF EXISTS "auth"."identities_user_id_idx";
DROP INDEX IF EXISTS "auth"."identities_email_idx";
DROP INDEX IF EXISTS "auth"."flow_state_created_at_idx";
DROP INDEX IF EXISTS "auth"."factor_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_new_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_current_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_provider_type_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_identifier_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_enabled_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_created_at_idx";
DROP INDEX IF EXISTS "auth"."confirmation_token_idx";
DROP INDEX IF EXISTS "auth"."audit_logs_instance_id_idx";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_name_key";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_vectors" DROP CONSTRAINT IF EXISTS "buckets_vectors_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets" DROP CONSTRAINT IF EXISTS "buckets_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_analytics" DROP CONSTRAINT IF EXISTS "buckets_analytics_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."subscription" DROP CONSTRAINT IF EXISTS "pk_subscription";
ALTER TABLE IF EXISTS "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_payload_exclusive";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_10" DROP CONSTRAINT IF EXISTS "messages_2026_08_10_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_09" DROP CONSTRAINT IF EXISTS "messages_2026_08_09_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_08" DROP CONSTRAINT IF EXISTS "messages_2026_08_08_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_07" DROP CONSTRAINT IF EXISTS "messages_2026_08_07_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_06" DROP CONSTRAINT IF EXISTS "messages_2026_08_06_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_pkey";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "unique_namhoc_tenchidoan";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "unique_chamdiem_record";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "tuanhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_matieuchi_namhoc_hocky_unique";
ALTER TABLE IF EXISTS ONLY "public"."thongbao_riengbiet" DROP CONSTRAINT IF EXISTS "thongbao_riengbiet_pkey";
ALTER TABLE IF EXISTS ONLY "public"."thongbao_hethong" DROP CONSTRAINT IF EXISTS "thongbao_hethong_pkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_pkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_username_key";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_ten_nam_unique";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "ql_nop_bc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ql_baocao" DROP CONSTRAINT IF EXISTS "ql_baocao_pkey";
ALTER TABLE IF EXISTS ONLY "public"."push_subscriptions" DROP CONSTRAINT IF EXISTS "push_subscriptions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."push_subscriptions" DROP CONSTRAINT IF EXISTS "push_subscriptions_endpoint_key";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "ptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_doi_tuong_tab_namhoc_unique";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_pkey";
ALTER TABLE IF EXISTS ONLY "public"."namhoc" DROP CONSTRAINT IF EXISTS "namhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."github_settings" DROP CONSTRAINT IF EXISTS "github_settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."duytricsdl" DROP CONSTRAINT IF EXISTS "duytricsdl_pkey";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "dotptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_pkey2";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_phone_key";
ALTER TABLE IF EXISTS ONLY "auth"."sso_providers" DROP CONSTRAINT IF EXISTS "sso_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_entity_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_token_unique";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_client_unique";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_clients" DROP CONSTRAINT IF EXISTS "oauth_clients_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_client_states" DROP CONSTRAINT IF EXISTS "oauth_client_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_code_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_last_challenged_at_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_authentication_method_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."instances" DROP CONSTRAINT IF EXISTS "instances_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_provider_id_provider_unique";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."flow_state" DROP CONSTRAINT IF EXISTS "flow_state_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_identifier_key";
ALTER TABLE IF EXISTS ONLY "auth"."audit_log_entries" DROP CONSTRAINT IF EXISTS "audit_log_entries_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "amr_id_pk";
ALTER TABLE IF EXISTS "auth"."refresh_tokens" ALTER COLUMN "id" DROP DEFAULT;
DROP TABLE IF EXISTS "storage"."vector_indexes";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads_parts";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads";
DROP TABLE IF EXISTS "storage"."objects";
DROP TABLE IF EXISTS "storage"."migrations";
DROP TABLE IF EXISTS "storage"."buckets_vectors";
DROP TABLE IF EXISTS "storage"."buckets_analytics";
DROP TABLE IF EXISTS "storage"."buckets";
DROP TABLE IF EXISTS "realtime"."subscription";
DROP TABLE IF EXISTS "realtime"."schema_migrations";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_10";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_09";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_08";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_07";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_06";
DROP TABLE IF EXISTS "realtime"."messages";
DROP TABLE IF EXISTS "public"."tuanhoc";
DROP TABLE IF EXISTS "public"."tieuchitd";
DROP TABLE IF EXISTS "public"."thongbao_riengbiet";
DROP TABLE IF EXISTS "public"."thongbao_hethong";
DROP TABLE IF EXISTS "public"."theodoi360";
DROP TABLE IF EXISTS "public"."settings";
DROP TABLE IF EXISTS "public"."qlchidoan";
DROP TABLE IF EXISTS "public"."ql_nop_bc";
DROP TABLE IF EXISTS "public"."ql_baocao";
DROP TABLE IF EXISTS "public"."push_subscriptions";
DROP TABLE IF EXISTS "public"."ptdoanvien";
DROP TABLE IF EXISTS "public"."phanquyen";
DROP TABLE IF EXISTS "public"."phancong";
DROP TABLE IF EXISTS "public"."namhoc";
DROP TABLE IF EXISTS "public"."github_settings";
DROP TABLE IF EXISTS "public"."duytricsdl";
DROP TABLE IF EXISTS "public"."dotptdoanvien";
DROP TABLE IF EXISTS "public"."doanvien";
DROP TABLE IF EXISTS "public"."chamdiem";
DROP TABLE IF EXISTS "public"."activity_logs";
DROP TABLE IF EXISTS "auth"."webauthn_credentials";
DROP TABLE IF EXISTS "auth"."webauthn_challenges";
DROP TABLE IF EXISTS "auth"."users";
DROP TABLE IF EXISTS "auth"."sso_providers";
DROP TABLE IF EXISTS "auth"."sso_domains";
DROP TABLE IF EXISTS "auth"."sessions";
DROP TABLE IF EXISTS "auth"."schema_migrations";
DROP TABLE IF EXISTS "auth"."saml_relay_states";
DROP TABLE IF EXISTS "auth"."saml_providers";
DROP SEQUENCE IF EXISTS "auth"."refresh_tokens_id_seq";
DROP TABLE IF EXISTS "auth"."refresh_tokens";
DROP TABLE IF EXISTS "auth"."one_time_tokens";
DROP TABLE IF EXISTS "auth"."oauth_consents";
DROP TABLE IF EXISTS "auth"."oauth_clients";
DROP TABLE IF EXISTS "auth"."oauth_client_states";
DROP TABLE IF EXISTS "auth"."oauth_authorizations";
DROP TABLE IF EXISTS "auth"."mfa_factors";
DROP TABLE IF EXISTS "auth"."mfa_challenges";
DROP TABLE IF EXISTS "auth"."mfa_amr_claims";
DROP TABLE IF EXISTS "auth"."instances";
DROP TABLE IF EXISTS "auth"."identities";
DROP TABLE IF EXISTS "auth"."flow_state";
DROP TABLE IF EXISTS "auth"."custom_oauth_providers";
DROP TABLE IF EXISTS "auth"."audit_log_entries";
DROP FUNCTION IF EXISTS "storage"."update_updated_at_column"();
DROP FUNCTION IF EXISTS "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text");
DROP FUNCTION IF EXISTS "storage"."protect_delete"();
DROP FUNCTION IF EXISTS "storage"."operation"();
DROP FUNCTION IF EXISTS "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text");
DROP FUNCTION IF EXISTS "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text");
DROP FUNCTION IF EXISTS "storage"."get_size_by_bucket"();
DROP FUNCTION IF EXISTS "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text");
DROP FUNCTION IF EXISTS "storage"."foldername"("name" "text");
DROP FUNCTION IF EXISTS "storage"."filename"("name" "text");
DROP FUNCTION IF EXISTS "storage"."extension"("name" "text");
DROP FUNCTION IF EXISTS "storage"."enforce_bucket_name_length"();
DROP FUNCTION IF EXISTS "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb");
DROP FUNCTION IF EXISTS "storage"."allow_only_operation"("expected_operation" "text");
DROP FUNCTION IF EXISTS "storage"."allow_any_operation"("expected_operations" "text"[]);
DROP FUNCTION IF EXISTS "realtime"."wal2json_escape_identifier"("name" "text");
DROP FUNCTION IF EXISTS "realtime"."topic"();
DROP FUNCTION IF EXISTS "realtime"."to_regrole"("role_name" "text");
DROP FUNCTION IF EXISTS "realtime"."subscription_check_filters"();
DROP FUNCTION IF EXISTS "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."quote_wal2json"("entity" "regclass");
DROP FUNCTION IF EXISTS "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text");
DROP FUNCTION IF EXISTS "realtime"."cast"("val" "text", "type_" "regtype");
DROP FUNCTION IF EXISTS "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]);
DROP FUNCTION IF EXISTS "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text");
DROP FUNCTION IF EXISTS "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "public"."update_modified_column"();
DROP FUNCTION IF EXISTS "public"."update_likes_count"();
DROP FUNCTION IF EXISTS "public"."rpc_get_user_by_username"("p_username" "text");
DROP TABLE IF EXISTS "public"."taikhoan";
DROP FUNCTION IF EXISTS "public"."handle_update_likes_count"();
DROP FUNCTION IF EXISTS "public"."handle_post_like"();
DROP FUNCTION IF EXISTS "public"."handle_chi_doan_deletion"();
DROP FUNCTION IF EXISTS "pgbouncer"."get_auth"("p_usename" "text");
DROP FUNCTION IF EXISTS "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb");
DROP FUNCTION IF EXISTS "extensions"."set_graphql_placeholder"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_drop_watch"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_ddl_watch"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_net_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_graphql_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_cron_access"();
DROP FUNCTION IF EXISTS "auth"."uid"();
DROP FUNCTION IF EXISTS "auth"."role"();
DROP FUNCTION IF EXISTS "auth"."jwt"();
DROP FUNCTION IF EXISTS "auth"."email"();
DROP TYPE IF EXISTS "storage"."buckettype";
DROP TYPE IF EXISTS "realtime"."wal_rls";
DROP TYPE IF EXISTS "realtime"."wal_column";
DROP TYPE IF EXISTS "realtime"."user_defined_filter";
DROP TYPE IF EXISTS "realtime"."equality_op";
DROP TYPE IF EXISTS "realtime"."action";
DROP TYPE IF EXISTS "auth"."one_time_token_type";
DROP TYPE IF EXISTS "auth"."oauth_response_type";
DROP TYPE IF EXISTS "auth"."oauth_registration_type";
DROP TYPE IF EXISTS "auth"."oauth_client_type";
DROP TYPE IF EXISTS "auth"."oauth_authorization_status";
DROP TYPE IF EXISTS "auth"."factor_type";
DROP TYPE IF EXISTS "auth"."factor_status";
DROP TYPE IF EXISTS "auth"."code_challenge_method";
DROP TYPE IF EXISTS "auth"."aal_level";
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS "supabase_vault";
DROP EXTENSION IF EXISTS "pgcrypto";
DROP EXTENSION IF EXISTS "pg_stat_statements";
DROP SCHEMA IF EXISTS "vault";
DROP SCHEMA IF EXISTS "storage";
DROP SCHEMA IF EXISTS "realtime";
DROP SCHEMA IF EXISTS "pgbouncer";
DROP SCHEMA IF EXISTS "graphql_public";
DROP SCHEMA IF EXISTS "graphql";
DROP SCHEMA IF EXISTS "extensions";
DROP SCHEMA IF EXISTS "auth";
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "auth";


ALTER SCHEMA "auth" OWNER TO "supabase_admin";

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "extensions";


ALTER SCHEMA "extensions" OWNER TO "postgres";

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql";


ALTER SCHEMA "graphql" OWNER TO "supabase_admin";

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql_public";


ALTER SCHEMA "graphql_public" OWNER TO "supabase_admin";

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA "pgbouncer";


ALTER SCHEMA "pgbouncer" OWNER TO "pgbouncer";

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "realtime";


ALTER SCHEMA "realtime" OWNER TO "supabase_admin";

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "storage";


ALTER SCHEMA "storage" OWNER TO "supabase_admin";

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "vault";


ALTER SCHEMA "vault" OWNER TO "supabase_admin";

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_stat_statements"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_stat_statements" IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgcrypto"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pgcrypto" IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";


--
-- Name: EXTENSION "supabase_vault"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "supabase_vault" IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."aal_level" AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE "auth"."aal_level" OWNER TO "supabase_auth_admin";

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."code_challenge_method" AS ENUM (
    's256',
    'plain'
);


ALTER TYPE "auth"."code_challenge_method" OWNER TO "supabase_auth_admin";

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_status" AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE "auth"."factor_status" OWNER TO "supabase_auth_admin";

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_type" AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE "auth"."factor_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_authorization_status" AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE "auth"."oauth_authorization_status" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_client_type" AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE "auth"."oauth_client_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_registration_type" AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE "auth"."oauth_registration_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_response_type" AS ENUM (
    'code'
);


ALTER TYPE "auth"."oauth_response_type" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."one_time_token_type" AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE "auth"."one_time_token_type" OWNER TO "supabase_auth_admin";

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."action" AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE "realtime"."action" OWNER TO "supabase_realtime_admin";

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."equality_op" AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


ALTER TYPE "realtime"."equality_op" OWNER TO "supabase_realtime_admin";

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."user_defined_filter" AS (
	"column_name" "text",
	"op" "realtime"."equality_op",
	"value" "text",
	"negate" boolean
);


ALTER TYPE "realtime"."user_defined_filter" OWNER TO "supabase_realtime_admin";

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."wal_column" AS (
	"name" "text",
	"type_name" "text",
	"type_oid" "oid",
	"value" "jsonb",
	"is_pkey" boolean,
	"is_selectable" boolean
);


ALTER TYPE "realtime"."wal_column" OWNER TO "supabase_realtime_admin";

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."wal_rls" AS (
	"wal" "jsonb",
	"is_rls_enabled" boolean,
	"subscription_ids" "uuid"[],
	"errors" "text"[]
);


ALTER TYPE "realtime"."wal_rls" OWNER TO "supabase_realtime_admin";

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE "storage"."buckettype" AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE "storage"."buckettype" OWNER TO "supabase_storage_admin";

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."email"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION "auth"."email"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "email"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."email"() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."jwt"() RETURNS "jsonb"
    LANGUAGE "sql" STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION "auth"."jwt"() OWNER TO "supabase_auth_admin";

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."role"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION "auth"."role"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "role"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."role"() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."uid"() RETURNS "uuid"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION "auth"."uid"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "uid"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."uid"() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_cron_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_cron_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_cron_access"() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_graphql_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
begin
    if not exists (
        select 1
        from pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


ALTER FUNCTION "extensions"."grant_pg_graphql_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_graphql_access"() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_net_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_net_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_net_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_net_access"() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_ddl_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_ddl_watch"() OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_drop_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_drop_watch"() OWNER TO "supabase_admin";

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."set_graphql_placeholder"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION "extensions"."set_graphql_placeholder"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."set_graphql_placeholder"() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql("text", "text", "jsonb", "jsonb"); Type: FUNCTION; Schema: graphql_public; Owner: supabase_admin
--

CREATE FUNCTION "graphql_public"."graphql"("operationName" "text" DEFAULT NULL::"text", "query" "text" DEFAULT NULL::"text", "variables" "jsonb" DEFAULT NULL::"jsonb", "extensions" "jsonb" DEFAULT NULL::"jsonb") RETURNS "jsonb"
    LANGUAGE "plpgsql"
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


ALTER FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") OWNER TO "supabase_admin";

--
-- Name: get_auth("text"); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION "pgbouncer"."get_auth"("p_usename" "text") RETURNS TABLE("username" "text", "password" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION "pgbouncer"."get_auth"("p_usename" "text") OWNER TO "supabase_admin";

--
-- Name: handle_chi_doan_deletion(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_chi_doan_deletion"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Sửa "chiDoan" thành chidoan (viết thường, không cần ngoặc kép)
    DELETE FROM "doanvien" 
    WHERE chidoan = OLD.tenchidoan;
    
    RETURN OLD;
END;
$$;


ALTER FUNCTION "public"."handle_chi_doan_deletion"() OWNER TO "postgres";

--
-- Name: handle_post_like(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_post_like"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_post_like"() OWNER TO "postgres";

--
-- Name: handle_update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = GREATEST(0, likes_count - 1) WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_update_likes_count"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: taikhoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."taikhoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "username" "text" NOT NULL,
    "password" "text" NOT NULL,
    "fullname" "text" NOT NULL,
    "role" "text" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "doanvien_id" "uuid",
    "sl_dangnhap" integer DEFAULT 0,
    "tg_truycap" timestamp with time zone
);


ALTER TABLE "public"."taikhoan" OWNER TO "postgres";

--
-- Name: rpc_get_user_by_username("text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") RETURNS SETOF "public"."taikhoan"
    LANGUAGE "sql" SECURITY DEFINER
    AS $$
  SELECT * FROM taikhoan WHERE username = p_username OR username = lower(p_username) LIMIT 1;
$$;


ALTER FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") OWNER TO "postgres";

--
-- Name: update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."update_likes_count"() OWNER TO "postgres";

--
-- Name: update_modified_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."update_modified_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updatedat = now();
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_modified_column"() OWNER TO "postgres";

--
-- Name: apply_rls("jsonb", integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer DEFAULT (1024 * 1024)) RETURNS SETOF "realtime"."wal_rls"
    LANGUAGE "plpgsql"
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    -- Reset the role on every FOR..LOOP batch execution.
                    -- The first batch of 10 rows is pre-fetched using the current connection role (PG internal behaviour)
                    -- then we have to reset it again otherwise it would use the role defined in the `set_config` above
                    -- to fetch the remaining rows when rows>10, which could be a user-defined role that lacks execution grants.
                    -- The flow is:
                    --   1. run batch with conn role
                    --   2. set_config working_role
                    --   3. execute walrus
                    --   4. reset role (revert)
                    --   5. repeat
                    perform set_config('role', null, true);

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) OWNER TO "supabase_realtime_admin";

--
-- Name: broadcast_changes("text", "text", "text", "text", "text", "record", "record", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text" DEFAULT 'ROW'::"text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: build_prepared_statement_sql("text", "regclass", "realtime"."wal_column"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) RETURNS "text"
    LANGUAGE "sql"
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) OWNER TO "supabase_realtime_admin";

--
-- Name: cast("text", "regtype"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") RETURNS "jsonb"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


ALTER FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") OWNER TO "supabase_realtime_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") RETURNS boolean
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) RETURNS boolean
    LANGUAGE "plpgsql" STABLE
    AS $$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) OWNER TO "supabase_realtime_admin";

--
-- Name: is_visible_through_filters("realtime"."wal_column"[], "realtime"."user_defined_filter"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
    select
        filters is null
        or array_length(filters, 1) is null
        or coalesce(
            count(col.name) = count(1)
            and sum(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(col.type_oid::regtype, col.type_name::regtype),
                    val_1:=col.value #>> '{}',
                    val_2:=f.value,
                    negate:=coalesce(f.negate, false)
                )::int
            ) filter (where col.name is not null) = count(col.name),
            false
        )
    from
        unnest(filters) f
        left join unnest(columns) col
            on f.column_name = col.name;
$$;


ALTER FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) OWNER TO "supabase_realtime_admin";

--
-- Name: list_changes("name", "name", integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) RETURNS TABLE("wal" "jsonb", "is_rls_enabled" boolean, "subscription_ids" "uuid"[], "errors" "text"[], "slot_changes_count" bigint)
    LANGUAGE "sql"
    SET "log_min_messages" TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


ALTER FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) OWNER TO "supabase_realtime_admin";

--
-- Name: quote_wal2json("regclass"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."quote_wal2json"("entity" "regclass") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


ALTER FUNCTION "realtime"."quote_wal2json"("entity" "regclass") OWNER TO "supabase_realtime_admin";

--
-- Name: send("jsonb", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_realtime_admin";

--
-- Name: send_binary("bytea", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_realtime_admin";

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."subscription_check_filters"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        elsif filter.op = 'is'::realtime.equality_op then
            -- `is` requires a keyword RHS rather than a typed literal
            if filter.value not in ('null', 'true', 'false', 'unknown') then
                raise exception 'invalid value for is filter: must be null, true, false, or unknown';
            end if;
            -- IS NULL works for any type, but IS TRUE/FALSE/UNKNOWN require a boolean
            -- operand. Reject the non-null keywords on non-boolean columns here so they
            -- don't abort apply_rls at WAL time.
            if filter.value <> 'null' and col_type <> 'boolean'::regtype then
                raise exception 'is % filter requires a boolean column, got %', filter.value, col_type::text;
            end if;
        elsif filter.op in ('like'::realtime.equality_op, 'ilike'::realtime.equality_op) then
            -- like/ilike apply the text pattern operator (~~); reject column types that
            -- have no such operator instead of failing at WAL time
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = '~~' and oprleft = col_type
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
        elsif filter.op in ('match'::realtime.equality_op, 'imatch'::realtime.equality_op) then
            -- match/imatch apply the regex operators ~ / ~*; reject column types that have
            -- no such operator (e.g. integer) instead of failing at WAL time, mirroring the
            -- like/ilike guard above.
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = case when filter.op = 'imatch'::realtime.equality_op then '~*' else '~' end
                  and oprleft = col_type
                  and oprright = col_type
                  and oprresult = 'boolean'::regtype
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
            -- validate the regex eagerly so a bad pattern is rejected here, not inside
            -- apply_rls where it would abort the WAL stream for the entity
            begin
                perform '' ~ filter.value;
            exception when others then
                raise exception 'invalid regular expression for % filter: %', filter.op::text, sqlerrm;
            end;
        else
            -- eq/neq/lt/lte/gt/gte: value must be coercable to the type
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    -- Apply consistent order to filters so the unique constraint can't be tricked by a
    -- different filter order. negate is part of the sort key.
    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value, f.negate),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


ALTER FUNCTION "realtime"."subscription_check_filters"() OWNER TO "supabase_realtime_admin";

--
-- Name: to_regrole("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."to_regrole"("role_name" "text") RETURNS "regrole"
    LANGUAGE "sql" IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION "realtime"."to_regrole"("role_name" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."topic"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION "realtime"."topic"() OWNER TO "supabase_realtime_admin";

--
-- Name: wal2json_escape_identifier("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


ALTER FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: allow_any_operation("text"[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


ALTER FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) OWNER TO "supabase_storage_admin";

--
-- Name: allow_only_operation("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_only_operation"("expected_operation" "text") RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


ALTER FUNCTION "storage"."allow_only_operation"("expected_operation" "text") OWNER TO "supabase_storage_admin";

--
-- Name: can_insert_object("text", "text", "uuid", "jsonb"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") OWNER TO "supabase_storage_admin";

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."enforce_bucket_name_length"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION "storage"."enforce_bucket_name_length"() OWNER TO "supabase_storage_admin";

--
-- Name: extension("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."extension"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION "storage"."extension"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: filename("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."filename"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION "storage"."filename"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: foldername("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."foldername"("name" "text") RETURNS "text"[]
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION "storage"."foldername"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_common_prefix("text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


ALTER FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_size_by_bucket"() RETURNS TABLE("size" bigint, "bucket_id" "text")
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION "storage"."get_size_by_bucket"() OWNER TO "supabase_storage_admin";

--
-- Name: list_multipart_uploads_with_delimiter("text", "text", "text", integer, "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "next_key_token" "text" DEFAULT ''::"text", "next_upload_token" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "id" "text", "created_at" timestamp with time zone)
    LANGUAGE "plpgsql"
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text") OWNER TO "supabase_storage_admin";

--
-- Name: list_objects_with_delimiter("text", "text", "text", integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "start_after" "text" DEFAULT ''::"text", "next_token" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "metadata" "jsonb", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone)
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text") OWNER TO "supabase_storage_admin";

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."operation"() RETURNS "text"
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION "storage"."operation"() OWNER TO "supabase_storage_admin";

--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."protect_delete"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION "storage"."protect_delete"() OWNER TO "supabase_storage_admin";

--
-- Name: search("text", "text", integer, integer, integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "offsets" integer DEFAULT 0, "search" "text" DEFAULT ''::"text", "sortcolumn" "text" DEFAULT 'name'::"text", "sortorder" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_by_timestamp("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


ALTER FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_v2("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "start_after" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text", "sort_column" "text" DEFAULT 'name'::"text", "sort_column_after" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


ALTER FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION "storage"."update_updated_at_column"() OWNER TO "supabase_storage_admin";

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."audit_log_entries" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "payload" json,
    "created_at" timestamp with time zone,
    "ip_address" character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE "auth"."audit_log_entries" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "audit_log_entries"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."audit_log_entries" IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."custom_oauth_providers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "provider_type" "text" NOT NULL,
    "identifier" "text" NOT NULL,
    "name" "text" NOT NULL,
    "client_id" "text" NOT NULL,
    "client_secret" "text" NOT NULL,
    "acceptable_client_ids" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "scopes" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "pkce_enabled" boolean DEFAULT true NOT NULL,
    "attribute_mapping" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "authorization_params" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL,
    "email_optional" boolean DEFAULT false NOT NULL,
    "issuer" "text",
    "discovery_url" "text",
    "skip_nonce_check" boolean DEFAULT false NOT NULL,
    "cached_discovery" "jsonb",
    "discovery_cached_at" timestamp with time zone,
    "authorization_url" "text",
    "token_url" "text",
    "userinfo_url" "text",
    "jwks_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "custom_claims_allowlist" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    CONSTRAINT "custom_oauth_providers_authorization_url_https" CHECK ((("authorization_url" IS NULL) OR ("authorization_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_authorization_url_length" CHECK ((("authorization_url" IS NULL) OR ("char_length"("authorization_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_client_id_length" CHECK ((("char_length"("client_id") >= 1) AND ("char_length"("client_id") <= 512))),
    CONSTRAINT "custom_oauth_providers_discovery_url_length" CHECK ((("discovery_url" IS NULL) OR ("char_length"("discovery_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_identifier_format" CHECK (("identifier" ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::"text")),
    CONSTRAINT "custom_oauth_providers_issuer_length" CHECK ((("issuer" IS NULL) OR (("char_length"("issuer") >= 1) AND ("char_length"("issuer") <= 2048)))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_https" CHECK ((("jwks_uri" IS NULL) OR ("jwks_uri" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_length" CHECK ((("jwks_uri" IS NULL) OR ("char_length"("jwks_uri") <= 2048))),
    CONSTRAINT "custom_oauth_providers_name_length" CHECK ((("char_length"("name") >= 1) AND ("char_length"("name") <= 100))),
    CONSTRAINT "custom_oauth_providers_oauth2_requires_endpoints" CHECK ((("provider_type" <> 'oauth2'::"text") OR (("authorization_url" IS NOT NULL) AND ("token_url" IS NOT NULL) AND ("userinfo_url" IS NOT NULL)))),
    CONSTRAINT "custom_oauth_providers_oidc_discovery_url_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("discovery_url" IS NULL) OR ("discovery_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_issuer_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NULL) OR ("issuer" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_requires_issuer" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NOT NULL))),
    CONSTRAINT "custom_oauth_providers_provider_type_check" CHECK (("provider_type" = ANY (ARRAY['oauth2'::"text", 'oidc'::"text"]))),
    CONSTRAINT "custom_oauth_providers_token_url_https" CHECK ((("token_url" IS NULL) OR ("token_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_token_url_length" CHECK ((("token_url" IS NULL) OR ("char_length"("token_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_https" CHECK ((("userinfo_url" IS NULL) OR ("userinfo_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_length" CHECK ((("userinfo_url" IS NULL) OR ("char_length"("userinfo_url") <= 2048)))
);


ALTER TABLE "auth"."custom_oauth_providers" OWNER TO "supabase_auth_admin";

--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."flow_state" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid",
    "auth_code" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "code_challenge" "text",
    "provider_type" "text" NOT NULL,
    "provider_access_token" "text",
    "provider_refresh_token" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "authentication_method" "text" NOT NULL,
    "auth_code_issued_at" timestamp with time zone,
    "invite_token" "text",
    "referrer" "text",
    "oauth_client_state_id" "uuid",
    "linking_target_id" "uuid",
    "email_optional" boolean DEFAULT false NOT NULL
);


ALTER TABLE "auth"."flow_state" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "flow_state"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."flow_state" IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."identities" (
    "provider_id" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "identity_data" "jsonb" NOT NULL,
    "provider" "text" NOT NULL,
    "last_sign_in_at" timestamp with time zone,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "email" "text" GENERATED ALWAYS AS ("lower"(("identity_data" ->> 'email'::"text"))) STORED,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "auth"."identities" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "identities"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."identities" IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN "identities"."email"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."identities"."email" IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."instances" (
    "id" "uuid" NOT NULL,
    "uuid" "uuid",
    "raw_base_config" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "auth"."instances" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "instances"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."instances" IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_amr_claims" (
    "session_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "authentication_method" "text" NOT NULL,
    "id" "uuid" NOT NULL
);


ALTER TABLE "auth"."mfa_amr_claims" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_amr_claims"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_amr_claims" IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_challenges" (
    "id" "uuid" NOT NULL,
    "factor_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "verified_at" timestamp with time zone,
    "ip_address" "inet" NOT NULL,
    "otp_code" "text",
    "web_authn_session_data" "jsonb"
);


ALTER TABLE "auth"."mfa_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_challenges"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_challenges" IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_factors" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "friendly_name" "text",
    "factor_type" "auth"."factor_type" NOT NULL,
    "status" "auth"."factor_status" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "secret" "text",
    "phone" "text",
    "last_challenged_at" timestamp with time zone,
    "web_authn_credential" "jsonb",
    "web_authn_aaguid" "uuid",
    "last_webauthn_challenge_data" "jsonb"
);


ALTER TABLE "auth"."mfa_factors" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_factors"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_factors" IS 'auth: stores metadata about factors';


--
-- Name: COLUMN "mfa_factors"."last_webauthn_challenge_data"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."mfa_factors"."last_webauthn_challenge_data" IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_authorizations" (
    "id" "uuid" NOT NULL,
    "authorization_id" "text" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "user_id" "uuid",
    "redirect_uri" "text" NOT NULL,
    "scope" "text" NOT NULL,
    "state" "text",
    "resource" "text",
    "code_challenge" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "response_type" "auth"."oauth_response_type" DEFAULT 'code'::"auth"."oauth_response_type" NOT NULL,
    "status" "auth"."oauth_authorization_status" DEFAULT 'pending'::"auth"."oauth_authorization_status" NOT NULL,
    "authorization_code" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '00:03:00'::interval) NOT NULL,
    "approved_at" timestamp with time zone,
    "nonce" "text",
    CONSTRAINT "oauth_authorizations_authorization_code_length" CHECK (("char_length"("authorization_code") <= 255)),
    CONSTRAINT "oauth_authorizations_code_challenge_length" CHECK (("char_length"("code_challenge") <= 128)),
    CONSTRAINT "oauth_authorizations_expires_at_future" CHECK (("expires_at" > "created_at")),
    CONSTRAINT "oauth_authorizations_nonce_length" CHECK (("char_length"("nonce") <= 255)),
    CONSTRAINT "oauth_authorizations_redirect_uri_length" CHECK (("char_length"("redirect_uri") <= 2048)),
    CONSTRAINT "oauth_authorizations_resource_length" CHECK (("char_length"("resource") <= 2048)),
    CONSTRAINT "oauth_authorizations_scope_length" CHECK (("char_length"("scope") <= 4096)),
    CONSTRAINT "oauth_authorizations_state_length" CHECK (("char_length"("state") <= 4096))
);


ALTER TABLE "auth"."oauth_authorizations" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_client_states" (
    "id" "uuid" NOT NULL,
    "provider_type" "text" NOT NULL,
    "code_verifier" "text",
    "created_at" timestamp with time zone NOT NULL
);


ALTER TABLE "auth"."oauth_client_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "oauth_client_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."oauth_client_states" IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_clients" (
    "id" "uuid" NOT NULL,
    "client_secret_hash" "text",
    "registration_type" "auth"."oauth_registration_type" NOT NULL,
    "redirect_uris" "text" NOT NULL,
    "grant_types" "text" NOT NULL,
    "client_name" "text",
    "client_uri" "text",
    "logo_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "client_type" "auth"."oauth_client_type" DEFAULT 'confidential'::"auth"."oauth_client_type" NOT NULL,
    "token_endpoint_auth_method" "text" NOT NULL,
    CONSTRAINT "oauth_clients_client_name_length" CHECK (("char_length"("client_name") <= 1024)),
    CONSTRAINT "oauth_clients_client_uri_length" CHECK (("char_length"("client_uri") <= 2048)),
    CONSTRAINT "oauth_clients_logo_uri_length" CHECK (("char_length"("logo_uri") <= 2048)),
    CONSTRAINT "oauth_clients_token_endpoint_auth_method_check" CHECK (("token_endpoint_auth_method" = ANY (ARRAY['client_secret_basic'::"text", 'client_secret_post'::"text", 'none'::"text"])))
);


ALTER TABLE "auth"."oauth_clients" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_consents" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "scopes" "text" NOT NULL,
    "granted_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "revoked_at" timestamp with time zone,
    CONSTRAINT "oauth_consents_revoked_after_granted" CHECK ((("revoked_at" IS NULL) OR ("revoked_at" >= "granted_at"))),
    CONSTRAINT "oauth_consents_scopes_length" CHECK (("char_length"("scopes") <= 2048)),
    CONSTRAINT "oauth_consents_scopes_not_empty" CHECK (("char_length"(TRIM(BOTH FROM "scopes")) > 0))
);


ALTER TABLE "auth"."oauth_consents" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."one_time_tokens" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token_type" "auth"."one_time_token_type" NOT NULL,
    "token_hash" "text" NOT NULL,
    "relates_to" "text" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "one_time_tokens_token_hash_check" CHECK (("char_length"("token_hash") > 0))
);


ALTER TABLE "auth"."one_time_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."refresh_tokens" (
    "instance_id" "uuid",
    "id" bigint NOT NULL,
    "token" character varying(255),
    "user_id" character varying(255),
    "revoked" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "parent" character varying(255),
    "session_id" "uuid"
);


ALTER TABLE "auth"."refresh_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "refresh_tokens"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."refresh_tokens" IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE "auth"."refresh_tokens_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNED BY "auth"."refresh_tokens"."id";


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_providers" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "entity_id" "text" NOT NULL,
    "metadata_xml" "text" NOT NULL,
    "metadata_url" "text",
    "attribute_mapping" "jsonb",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "name_id_format" "text",
    CONSTRAINT "entity_id not empty" CHECK (("char_length"("entity_id") > 0)),
    CONSTRAINT "metadata_url not empty" CHECK ((("metadata_url" = NULL::"text") OR ("char_length"("metadata_url") > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK (("char_length"("metadata_xml") > 0))
);


ALTER TABLE "auth"."saml_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_providers" IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_relay_states" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "request_id" "text" NOT NULL,
    "for_email" "text",
    "redirect_to" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "flow_state_id" "uuid",
    CONSTRAINT "request_id not empty" CHECK (("char_length"("request_id") > 0))
);


ALTER TABLE "auth"."saml_relay_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_relay_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_relay_states" IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."schema_migrations" (
    "version" character varying(255) NOT NULL
);


ALTER TABLE "auth"."schema_migrations" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "schema_migrations"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."schema_migrations" IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sessions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "factor_id" "uuid",
    "aal" "auth"."aal_level",
    "not_after" timestamp with time zone,
    "refreshed_at" timestamp without time zone,
    "user_agent" "text",
    "ip" "inet",
    "tag" "text",
    "oauth_client_id" "uuid",
    "refresh_token_hmac_key" "text",
    "refresh_token_counter" bigint,
    "scopes" "text",
    CONSTRAINT "sessions_scopes_length" CHECK (("char_length"("scopes") <= 4096))
);


ALTER TABLE "auth"."sessions" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sessions"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sessions" IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN "sessions"."not_after"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."not_after" IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN "sessions"."refresh_token_hmac_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_hmac_key" IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN "sessions"."refresh_token_counter"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_counter" IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_domains" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "domain" "text" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK (("char_length"("domain") > 0))
);


ALTER TABLE "auth"."sso_domains" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_domains"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_domains" IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_providers" (
    "id" "uuid" NOT NULL,
    "resource_id" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "disabled" boolean,
    CONSTRAINT "resource_id not empty" CHECK ((("resource_id" = NULL::"text") OR ("char_length"("resource_id") > 0)))
);


ALTER TABLE "auth"."sso_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_providers" IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN "sso_providers"."resource_id"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sso_providers"."resource_id" IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."users" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "aud" character varying(255),
    "role" character varying(255),
    "email" character varying(255),
    "encrypted_password" character varying(255),
    "email_confirmed_at" timestamp with time zone,
    "invited_at" timestamp with time zone,
    "confirmation_token" character varying(255),
    "confirmation_sent_at" timestamp with time zone,
    "recovery_token" character varying(255),
    "recovery_sent_at" timestamp with time zone,
    "email_change_token_new" character varying(255),
    "email_change" character varying(255),
    "email_change_sent_at" timestamp with time zone,
    "last_sign_in_at" timestamp with time zone,
    "raw_app_meta_data" "jsonb",
    "raw_user_meta_data" "jsonb",
    "is_super_admin" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "phone" "text" DEFAULT NULL::character varying,
    "phone_confirmed_at" timestamp with time zone,
    "phone_change" "text" DEFAULT ''::character varying,
    "phone_change_token" character varying(255) DEFAULT ''::character varying,
    "phone_change_sent_at" timestamp with time zone,
    "confirmed_at" timestamp with time zone GENERATED ALWAYS AS (LEAST("email_confirmed_at", "phone_confirmed_at")) STORED,
    "email_change_token_current" character varying(255) DEFAULT ''::character varying,
    "email_change_confirm_status" smallint DEFAULT 0,
    "banned_until" timestamp with time zone,
    "reauthentication_token" character varying(255) DEFAULT ''::character varying,
    "reauthentication_sent_at" timestamp with time zone,
    "is_sso_user" boolean DEFAULT false NOT NULL,
    "deleted_at" timestamp with time zone,
    "is_anonymous" boolean DEFAULT false NOT NULL,
    CONSTRAINT "users_email_change_confirm_status_check" CHECK ((("email_change_confirm_status" >= 0) AND ("email_change_confirm_status" <= 2)))
);


ALTER TABLE "auth"."users" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "users"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."users" IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN "users"."is_sso_user"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."users"."is_sso_user" IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_challenges" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "challenge_type" "text" NOT NULL,
    "session_data" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    CONSTRAINT "webauthn_challenges_challenge_type_check" CHECK (("challenge_type" = ANY (ARRAY['signup'::"text", 'registration'::"text", 'authentication'::"text"])))
);


ALTER TABLE "auth"."webauthn_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_credentials" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "credential_id" "bytea" NOT NULL,
    "public_key" "bytea" NOT NULL,
    "attestation_type" "text" DEFAULT ''::"text" NOT NULL,
    "aaguid" "uuid",
    "sign_count" bigint DEFAULT 0 NOT NULL,
    "transports" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "backup_eligible" boolean DEFAULT false NOT NULL,
    "backed_up" boolean DEFAULT false NOT NULL,
    "friendly_name" "text" DEFAULT ''::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_used_at" timestamp with time zone
);


ALTER TABLE "auth"."webauthn_credentials" OWNER TO "supabase_auth_admin";

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."activity_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "username" "text" NOT NULL,
    "full_name" "text" NOT NULL,
    "tab_name" "text" NOT NULL,
    "table_name" "text" NOT NULL,
    "action_type" "text" NOT NULL,
    "description" "text" NOT NULL,
    "old_data" "jsonb",
    "new_data" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid"
);


ALTER TABLE "public"."activity_logs" OWNER TO "postgres";

--
-- Name: chamdiem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."chamdiem" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "namhoc" "uuid",
    "hocky" "text",
    "tuan" "text",
    "thu" "text",
    "ngay" "text",
    "lopcham" "uuid",
    "chamlop" "uuid",
    "doanvienid" "uuid",
    "hotendoanvien" "text",
    "matieuchi" "text",
    "tentieuchi" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "nguoicham" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."chamdiem" OWNER TO "postgres";

--
-- Name: doanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."doanvien" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hoten" "text" NOT NULL,
    "ngaysinh" "text",
    "gioitinh" "text",
    "dantoc" "text",
    "doituong" "text",
    "doanvien" boolean DEFAULT false,
    "chidoan" "text",
    "ngayvaodoan" "text",
    "sdt" "text",
    "thongtinthem" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "diachi" "text",
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."doanvien" OWNER TO "postgres";

--
-- Name: dotptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."dotptdoanvien" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tendot" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."dotptdoanvien" OWNER TO "postgres";

--
-- Name: duytricsdl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."duytricsdl" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "so" bigint DEFAULT 0,
    "thoigian" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."duytricsdl" OWNER TO "postgres";

--
-- Name: github_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."github_settings" (
    "id" "text" NOT NULL,
    "github_repo_path" "text",
    "github_branch" "text" DEFAULT 'main'::"text",
    "github_workflow_file" "text" DEFAULT 'supabase-backup.yml'::"text",
    "github_restore_workflow_file" "text" DEFAULT 'supabase-restore.yml'::"text",
    "github_token" "text",
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "updated_by" "text",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."github_settings" OWNER TO "postgres";

--
-- Name: namhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."namhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tennamhoc" "text" NOT NULL,
    "islocked" boolean DEFAULT false,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "isdefault" boolean DEFAULT false
);


ALTER TABLE "public"."namhoc" OWNER TO "postgres";

--
-- Name: phancong; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phancong" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "lopcham" "uuid" NOT NULL,
    "chamlop" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."phancong" OWNER TO "postgres";

--
-- Name: phanquyen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phanquyen" (
    "id" bigint NOT NULL,
    "doi_tuong" character varying(50) NOT NULL,
    "tab_chuc_nang" character varying(100) NOT NULL,
    "ngay_cap_nhat" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "nam_hoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "quyen_xem" boolean DEFAULT false,
    "quyen_them" boolean DEFAULT false,
    "quyen_sua" boolean DEFAULT false,
    "quyen_xoa" boolean DEFAULT false,
    "giai_thich" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."phanquyen" OWNER TO "postgres";

--
-- Name: TABLE "phanquyen"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE "public"."phanquyen" IS 'Bảng cấu hình phân quyền động cho hệ thống';


--
-- Name: COLUMN "phanquyen"."doi_tuong"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."doi_tuong" IS 'Vai trò của người dùng (Admin, BTV, BCH, BT, DV)';


--
-- Name: COLUMN "phanquyen"."tab_chuc_nang"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."tab_chuc_nang" IS 'Mã tab chức năng trên giao diện';


--
-- Name: phanquyen_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."phanquyen_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ptdoanvien" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "doanvien_id" "uuid",
    "dotdangki" "uuid",
    "thongkerenluyen" "text",
    "diemrenluyen" integer DEFAULT 0,
    "pheduyet" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "soquyetdinh" "text",
    "ngayquyetdinh" "date"
);


ALTER TABLE "public"."ptdoanvien" OWNER TO "postgres";

--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."push_subscriptions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "role" "text",
    "chidoan_id" "uuid",
    "subscription" "jsonb" NOT NULL,
    "endpoint" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."push_subscriptions" OWNER TO "postgres";

--
-- Name: ql_baocao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ql_baocao" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "chu_de" "text" NOT NULL,
    "chu_de_phu" "text",
    "tu_ngay" "date",
    "den_ngay" "date",
    "cho_phep_minh_chung" boolean DEFAULT true,
    "doi_tuong_nop" "text",
    "huong_dan" "text",
    "ngay_tao" timestamp with time zone DEFAULT "now"(),
    "nam_hoc_id" "uuid",
    "hoc_ky" "text",
    "config_noi_dung1" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 1", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung2" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 2", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung3" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 3", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung4" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 4", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung5" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 5", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung6" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 6", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung7" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 7", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung8" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 8", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung9" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 9", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung10" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 10", "enabled": true, "options": "", "required": false}'::"jsonb",
    "allowed_file_types" "text" DEFAULT 'image,video,pdf,doc'::"text",
    "max_file_size" integer DEFAULT 10
);


ALTER TABLE "public"."ql_baocao" OWNER TO "postgres";

--
-- Name: COLUMN "ql_baocao"."config_noi_dung1"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung1" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 1';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung2"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung2" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 2';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung3"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung3" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 3';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung4"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung4" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 4';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung5"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung5" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 5';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung6"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung6" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 6';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung7"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung7" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 7';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung8"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung8" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 8';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung9"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung9" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 9';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung10"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung10" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 10';


--
-- Name: ql_nop_bc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ql_nop_bc" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "ql_bao_cao_id" "uuid" NOT NULL,
    "doanvien_id" "uuid",
    "noi_dung1" "text",
    "noi_dung2" "text",
    "noi_dung3" "text",
    "noi_dung4" "text",
    "noi_dung5" "text",
    "noi_dung6" "text",
    "noi_dung7" "text",
    "noi_dung8" "text",
    "noi_dung9" "text",
    "noi_dung10" "text",
    "duong_dan_minh_chung" "text",
    "ghi_chu" "text",
    "trang_thai" "text",
    "ngay_capnhat" timestamp with time zone DEFAULT "now"(),
    "chi_doan_id" "uuid",
    "danh_sach_anh" "text",
    "vaitro_nop" "text",
    "doituong_nop" "text",
    "nguoi_tao_id" "text"
);


ALTER TABLE "public"."ql_nop_bc" OWNER TO "postgres";

--
-- Name: COLUMN "ql_nop_bc"."danh_sach_anh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_nop_bc"."danh_sach_anh" IS 'Danh sách liên kết các ảnh minh chứng tải lên R2, phân tách bằng dấu phẩy';


--
-- Name: qlchidoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."qlchidoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tenchidoan" "text" NOT NULL,
    "buoihoc" "text" NOT NULL,
    "ban" "text",
    "phonghoc" "text",
    "bithu" "text",
    "gvcn" "text",
    "namhoc" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."qlchidoan" OWNER TO "postgres";

--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."settings" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "title1" "text",
    "title2" "text",
    "diemsan" numeric,
    "aiprompttemplate" "text",
    "geminiapikey" "text",
    "diemsanhocky" numeric DEFAULT 0,
    "aiassistantprompt" "text",
    "thongbaochamdiem" "text",
    "doituongthongbao" "text",
    "noidungthongbao" "text",
    "thongbaodoanvien" "text",
    "autopenaltytime" "text" DEFAULT '23:55'::"text",
    "autopenaltypoints" integer DEFAULT 30,
    "autopenaltycriteria" "text" DEFAULT 'Lỗi không báo cáo điểm tuần'::"text",
    "autopenaltyenabled" boolean DEFAULT false,
    "autopenaltyreporter" "text" DEFAULT 'Hệ thống tự động'::"text",
    "autopenaltyday" integer DEFAULT 0,
    "thongbaophattriendoan" "text" DEFAULT ''::"text",
    "excel_header_left" "text",
    "excel_header_right" "text",
    "excel_footer_left" "text",
    "excel_footer_right" "text",
    "word_header_left" "text",
    "word_header_right" "text",
    "word_footer_left" "text",
    "word_footer_right" "text",
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "cloudinary_cloud_name" "text",
    "cloudinary_upload_preset" "text",
    "cloudinary_api_key" "text",
    "cloudinary_api_secret" "text",
    "r2_account_id" "text",
    "r2_access_key_id" "text",
    "r2_secret_access_key" "text",
    "r2_bucket_name" "text",
    "r2_custom_domain" "text",
    "show_class_select_gvcn" "text" DEFAULT 'Không hiển thị'::"text"
);


ALTER TABLE "public"."settings" OWNER TO "postgres";

--
-- Name: COLUMN "settings"."autopenaltytime"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltytime" IS 'Giờ kiểm tra xử phạt tự động vào Chủ Nhật';


--
-- Name: COLUMN "settings"."autopenaltypoints"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltypoints" IS 'Số điểm trừ khi vi phạm lỗi không nhập điểm';


--
-- Name: COLUMN "settings"."autopenaltycriteria"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltycriteria" IS 'Tên tiêu chí hiển thị khi xử phạt';


--
-- Name: COLUMN "settings"."autopenaltyenabled"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyenabled" IS 'Trạng thái bật/tắt chức năng xử phạt tự động';


--
-- Name: COLUMN "settings"."autopenaltyreporter"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyreporter" IS 'Tên người chấm hiển thị trong bảng điểm';


--
-- Name: theodoi360; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."theodoi360" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "nguoi_to_cao_id" "uuid" NOT NULL,
    "doan_vien_vi_pham_id" "uuid" NOT NULL,
    "tieu_chi_id" "uuid" NOT NULL,
    "chi_tiet_vi_pham" "text",
    "danh_sach_hinh_anh" "jsonb" DEFAULT '[]'::"jsonb",
    "url_video" "text",
    "trang_thai" "text" DEFAULT 'cho_duyet'::"text",
    "nam_hoc_id" "uuid" NOT NULL,
    "tuan_id" "uuid" NOT NULL,
    "ngay_vi_pham" "date",
    "ngay_tao" timestamp with time zone DEFAULT "now"(),
    "hoc_ky" "text",
    "phan_hoi_bi_to_cao" "text",
    "phan_hoi_lop" "text",
    "minh_chung_drive" "text"
);


ALTER TABLE "public"."theodoi360" OWNER TO "postgres";

--
-- Name: thongbao_hethong; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."thongbao_hethong" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "title" "text" NOT NULL,
    "content" "text" NOT NULL,
    "sender" "text" DEFAULT 'Hệ thống'::"text",
    "target_role" "text" DEFAULT 'all'::"text",
    "target_chidoan_id" "uuid",
    "target_user_id" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "read_by" "jsonb" DEFAULT '[]'::"jsonb"
);


ALTER TABLE "public"."thongbao_hethong" OWNER TO "postgres";

--
-- Name: thongbao_riengbiet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."thongbao_riengbiet" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "text" NOT NULL,
    "sender_id" "text" NOT NULL,
    "sender_name" "text" NOT NULL,
    "sender_role" "text" NOT NULL,
    "title" "text" NOT NULL,
    "content" "text" NOT NULL,
    "attachments" "jsonb" DEFAULT '[]'::"jsonb",
    "target_roles" "text"[] DEFAULT '{}'::"text"[],
    "target_chidoan_ids" "text"[] DEFAULT '{}'::"text"[],
    "start_at" timestamp with time zone NOT NULL,
    "end_at" timestamp with time zone NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "read_by" "text"[] DEFAULT '{}'::"text"[]
);


ALTER TABLE "public"."thongbao_riengbiet" OWNER TO "postgres";

--
-- Name: tieuchitd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tieuchitd" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "matieuchi" "text" NOT NULL,
    "tentieuchi" "text" NOT NULL,
    "mota" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "hocky" "text",
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tieuchitd" OWNER TO "postgres";

--
-- Name: tuanhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tuanhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tuanhoc" OWNER TO "postgres";

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea"
)
PARTITION BY RANGE ("inserted_at");


ALTER TABLE "realtime"."messages" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_06; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_06" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_06" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_07; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_07" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_07" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_08; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_08" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_08" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_09; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_09" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_09" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_10; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_10" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_10" OWNER TO "supabase_realtime_admin";

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."schema_migrations" (
    "version" bigint NOT NULL,
    "inserted_at" timestamp(0) without time zone DEFAULT "now"()
);


ALTER TABLE "realtime"."schema_migrations" OWNER TO "supabase_admin";

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."subscription" (
    "id" bigint NOT NULL,
    "subscription_id" "uuid" NOT NULL,
    "entity" "regclass" NOT NULL,
    "filters" "realtime"."user_defined_filter"[] DEFAULT '{}'::"realtime"."user_defined_filter"[] NOT NULL,
    "claims" "jsonb" NOT NULL,
    "claims_role" "regrole" GENERATED ALWAYS AS ("realtime"."to_regrole"(("claims" ->> 'role'::"text"))) STORED NOT NULL,
    "created_at" timestamp without time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "action_filter" "text" DEFAULT '*'::"text",
    "selected_columns" "text"[],
    CONSTRAINT "subscription_action_filter_check" CHECK (("action_filter" = ANY (ARRAY['*'::"text", 'INSERT'::"text", 'UPDATE'::"text", 'DELETE'::"text"])))
);


ALTER TABLE "realtime"."subscription" OWNER TO "supabase_realtime_admin";

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."subscription" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "realtime"."subscription_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "public" boolean DEFAULT false,
    "avif_autodetection" boolean DEFAULT false,
    "file_size_limit" bigint,
    "allowed_mime_types" "text"[],
    "owner_id" "text",
    "type" "storage"."buckettype" DEFAULT 'STANDARD'::"storage"."buckettype" NOT NULL
);


ALTER TABLE "storage"."buckets" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "buckets"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."buckets"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_analytics" (
    "name" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'ANALYTICS'::"storage"."buckettype" NOT NULL,
    "format" "text" DEFAULT 'ICEBERG'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "deleted_at" timestamp with time zone
);


ALTER TABLE "storage"."buckets_analytics" OWNER TO "supabase_storage_admin";

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_vectors" (
    "id" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'VECTOR'::"storage"."buckettype" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."buckets_vectors" OWNER TO "supabase_storage_admin";

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."migrations" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL,
    "hash" character varying(40) NOT NULL,
    "executed_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "storage"."migrations" OWNER TO "supabase_storage_admin";

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."objects" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "bucket_id" "text",
    "name" "text",
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_accessed_at" timestamp with time zone DEFAULT "now"(),
    "metadata" "jsonb",
    "path_tokens" "text"[] GENERATED ALWAYS AS ("string_to_array"("name", '/'::"text")) STORED,
    "version" "text",
    "owner_id" "text",
    "user_metadata" "jsonb"
);


ALTER TABLE "storage"."objects" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "objects"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."objects"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads" (
    "id" "text" NOT NULL,
    "in_progress_size" bigint DEFAULT 0 NOT NULL,
    "upload_signature" "text" NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "version" "text" NOT NULL,
    "owner_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "user_metadata" "jsonb",
    "metadata" "jsonb"
);


ALTER TABLE "storage"."s3_multipart_uploads" OWNER TO "supabase_storage_admin";

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads_parts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "upload_id" "text" NOT NULL,
    "size" bigint DEFAULT 0 NOT NULL,
    "part_number" integer NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "etag" "text" NOT NULL,
    "owner_id" "text",
    "version" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."s3_multipart_uploads_parts" OWNER TO "supabase_storage_admin";

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."vector_indexes" (
    "id" "text" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL COLLATE "pg_catalog"."C",
    "bucket_id" "text" NOT NULL,
    "data_type" "text" NOT NULL,
    "dimension" integer NOT NULL,
    "distance_metric" "text" NOT NULL,
    "metadata_configuration" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."vector_indexes" OWNER TO "supabase_storage_admin";

--
-- Name: messages_2026_08_06; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_06" FOR VALUES FROM ('2026-08-06 00:00:00') TO ('2026-08-07 00:00:00');


--
-- Name: messages_2026_08_07; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_07" FOR VALUES FROM ('2026-08-07 00:00:00') TO ('2026-08-08 00:00:00');


--
-- Name: messages_2026_08_08; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_08" FOR VALUES FROM ('2026-08-08 00:00:00') TO ('2026-08-09 00:00:00');


--
-- Name: messages_2026_08_09; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_09" FOR VALUES FROM ('2026-08-09 00:00:00') TO ('2026-08-10 00:00:00');


--
-- Name: messages_2026_08_10; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_10" FOR VALUES FROM ('2026-08-10 00:00:00') TO ('2026-08-11 00:00:00');


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens" ALTER COLUMN "id" SET DEFAULT "nextval"('"auth"."refresh_tokens_id_seq"'::"regclass");


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."custom_oauth_providers" ("id", "provider_type", "identifier", "name", "client_id", "client_secret", "acceptable_client_ids", "scopes", "pkce_enabled", "attribute_mapping", "authorization_params", "enabled", "email_optional", "issuer", "discovery_url", "skip_nonce_check", "cached_discovery", "discovery_cached_at", "authorization_url", "token_url", "userinfo_url", "jwks_uri", "created_at", "updated_at", "custom_claims_allowlist") FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."flow_state" ("id", "user_id", "auth_code", "code_challenge_method", "code_challenge", "provider_type", "provider_access_token", "provider_refresh_token", "created_at", "updated_at", "authentication_method", "auth_code_issued_at", "invite_token", "referrer", "oauth_client_state_id", "linking_target_id", "email_optional") FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") FROM stdin;
b9c56da5-5cb3-415d-9779-892b80f62d28	b9c56da5-5cb3-415d-9779-892b80f62d28	{"sub": "b9c56da5-5cb3-415d-9779-892b80f62d28", "email": "admin@schmsij376jzqgi.com", "email_verified": false, "phone_verified": false}	email	2026-08-07 05:55:34.552572+00	2026-08-07 05:55:34.552653+00	2026-08-07 05:55:34.552653+00	eda5be41-f2ef-43fd-bb99-b92b3ff65962
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") FROM stdin;
4c8784ef-74e5-4774-8b2b-944cae9182d6	2026-08-07 05:55:34.587059+00	2026-08-07 05:55:34.587059+00	password	a53267bc-b67e-4192-85a3-e44d765553ca
a2436a65-89ba-4983-aad4-45036963ec61	2026-08-07 06:06:02.328082+00	2026-08-07 06:06:02.328082+00	password	b6ec1b82-c48f-4e85-93ba-6b62ac3e698f
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_challenges" ("id", "factor_id", "created_at", "verified_at", "ip_address", "otp_code", "web_authn_session_data") FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_factors" ("id", "user_id", "friendly_name", "factor_type", "status", "created_at", "updated_at", "secret", "phone", "last_challenged_at", "web_authn_credential", "web_authn_aaguid", "last_webauthn_challenge_data") FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_authorizations" ("id", "authorization_id", "client_id", "user_id", "redirect_uri", "scope", "state", "resource", "code_challenge", "code_challenge_method", "response_type", "status", "authorization_code", "created_at", "expires_at", "approved_at", "nonce") FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_client_states" ("id", "provider_type", "code_verifier", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_clients" ("id", "client_secret_hash", "registration_type", "redirect_uris", "grant_types", "client_name", "client_uri", "logo_uri", "created_at", "updated_at", "deleted_at", "client_type", "token_endpoint_auth_method") FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_consents" ("id", "user_id", "client_id", "scopes", "granted_at", "revoked_at") FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."one_time_tokens" ("id", "user_id", "token_type", "token_hash", "relates_to", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") FROM stdin;
00000000-0000-0000-0000-000000000000	2	z353ryk6srfr	b9c56da5-5cb3-415d-9779-892b80f62d28	f	2026-08-07 06:06:02.321564+00	2026-08-07 06:06:02.321564+00	\N	a2436a65-89ba-4983-aad4-45036963ec61
00000000-0000-0000-0000-000000000000	1	alk4cyjo36ms	b9c56da5-5cb3-415d-9779-892b80f62d28	t	2026-08-07 05:55:34.577383+00	2026-08-07 06:55:02.944613+00	\N	4c8784ef-74e5-4774-8b2b-944cae9182d6
00000000-0000-0000-0000-000000000000	3	2cntpxvj5efc	b9c56da5-5cb3-415d-9779-892b80f62d28	t	2026-08-07 06:55:02.962734+00	2026-08-07 07:54:02.894929+00	alk4cyjo36ms	4c8784ef-74e5-4774-8b2b-944cae9182d6
00000000-0000-0000-0000-000000000000	4	wu2thk4kodb5	b9c56da5-5cb3-415d-9779-892b80f62d28	t	2026-08-07 07:54:02.910824+00	2026-08-07 08:53:02.74488+00	2cntpxvj5efc	4c8784ef-74e5-4774-8b2b-944cae9182d6
00000000-0000-0000-0000-000000000000	5	to4wdc7vggal	b9c56da5-5cb3-415d-9779-892b80f62d28	t	2026-08-07 08:53:02.75937+00	2026-08-07 09:52:02.726215+00	wu2thk4kodb5	4c8784ef-74e5-4774-8b2b-944cae9182d6
00000000-0000-0000-0000-000000000000	6	tk6t4zlewc5x	b9c56da5-5cb3-415d-9779-892b80f62d28	t	2026-08-07 09:52:02.742555+00	2026-08-07 10:51:02.619141+00	to4wdc7vggal	4c8784ef-74e5-4774-8b2b-944cae9182d6
00000000-0000-0000-0000-000000000000	7	zp73ab7ia5cq	b9c56da5-5cb3-415d-9779-892b80f62d28	t	2026-08-07 10:51:02.633939+00	2026-08-07 12:56:52.835746+00	tk6t4zlewc5x	4c8784ef-74e5-4774-8b2b-944cae9182d6
00000000-0000-0000-0000-000000000000	8	tbi22uztezoe	b9c56da5-5cb3-415d-9779-892b80f62d28	t	2026-08-07 12:56:52.850328+00	2026-08-07 13:55:57.540534+00	zp73ab7ia5cq	4c8784ef-74e5-4774-8b2b-944cae9182d6
00000000-0000-0000-0000-000000000000	9	qjvp4fwgcaon	b9c56da5-5cb3-415d-9779-892b80f62d28	f	2026-08-07 13:55:57.556983+00	2026-08-07 13:55:57.556983+00	tbi22uztezoe	4c8784ef-74e5-4774-8b2b-944cae9182d6
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_providers" ("id", "sso_provider_id", "entity_id", "metadata_xml", "metadata_url", "attribute_mapping", "created_at", "updated_at", "name_id_format") FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_relay_states" ("id", "sso_provider_id", "request_id", "for_email", "redirect_to", "created_at", "updated_at", "flow_state_id") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."schema_migrations" ("version") FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") FROM stdin;
a2436a65-89ba-4983-aad4-45036963ec61	b9c56da5-5cb3-415d-9779-892b80f62d28	2026-08-07 06:06:02.310214+00	2026-08-07 06:06:02.310214+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
4c8784ef-74e5-4774-8b2b-944cae9182d6	b9c56da5-5cb3-415d-9779-892b80f62d28	2026-08-07 05:55:34.570449+00	2026-08-07 13:55:57.579919+00	\N	aal1	\N	2026-08-07 13:55:57.579783	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_domains" ("id", "sso_provider_id", "domain", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_providers" ("id", "resource_id", "created_at", "updated_at", "disabled") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") FROM stdin;
00000000-0000-0000-0000-000000000000	b9c56da5-5cb3-415d-9779-892b80f62d28	authenticated	authenticated	admin@schmsij376jzqgi.com	$2a$10$LTEIzn/dxl547e0IvZH.5OQAp0ZIwHkFnpAQ/GYiRWLj2U.Mqmfr2	2026-08-07 05:55:34.560939+00	\N		\N		\N			\N	2026-08-07 06:06:02.310123+00	{"provider": "email", "providers": ["email"]}	{"sub": "b9c56da5-5cb3-415d-9779-892b80f62d28", "email": "admin@schmsij376jzqgi.com", "email_verified": true, "phone_verified": false}	\N	2026-08-07 05:55:34.517474+00	2026-08-07 13:55:57.564147+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_challenges" ("id", "user_id", "challenge_type", "session_data", "created_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_credentials" ("id", "user_id", "credential_id", "public_key", "attestation_type", "aaguid", "sign_count", "transports", "backup_eligible", "backed_up", "friendly_name", "created_at", "updated_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."activity_logs" ("id", "user_id", "username", "full_name", "tab_name", "table_name", "action_type", "description", "old_data", "new_data", "created_at", "namhoc") FROM stdin;
\.


--
-- Data for Name: chamdiem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."chamdiem" ("id", "namhoc", "hocky", "tuan", "thu", "ngay", "lopcham", "chamlop", "doanvienid", "hotendoanvien", "matieuchi", "tentieuchi", "loaitieuchi", "diemtru", "diemcong", "ghichu", "nguoicham", "updatedat", "chidoan_id", "createdat") FROM stdin;
\.


--
-- Data for Name: doanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."doanvien" ("id", "hoten", "ngaysinh", "gioitinh", "dantoc", "doituong", "doanvien", "chidoan", "ngayvaodoan", "sdt", "thongtinthem", "updatedat", "namhoc", "diachi", "chidoan_id", "createdat") FROM stdin;
937879cb-79e6-4419-b94d-c492c97295b6	Nguyễn Phạm Dương Anh	20/10/2026	Nam	Kinh	\N	t	\N	17/01/2026	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
39709ec2-ffde-4b79-a136-1a91d75ce869	Nguyễn Phạm Văn Bé	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
30e916b2-0146-4b8c-affc-362d3ba48279	Nguyễn Lương Thanh Bình	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
752d887b-2558-4b50-92d8-7257700ac5fd	Nguyễn Bùi Ngọc Đạt	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
462ea5ed-e358-413b-98d0-f8a3b83d62fa	Nguyễn TRẦN KHÁNH HÀ	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
e609a225-c441-44df-9326-be89eb61f4e5	Nguyễn Nguyễn Công Hậu	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
4193f721-5cb9-460b-ab74-eeab57a23bba	Nguyễn Nguyễn Đức Hiếu	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
1f7b0864-c36c-4bee-913b-121f7417bead	Nguyễn Nguyễn Văn Hiếu	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
9c9d1902-6857-48db-bc62-c7773fa78231	Nguyễn Lê Thị Thúy Hoài	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
175e4407-cfd0-43f3-8d25-6feecff8b38e	Nguyễn Đinh Ngọc Khánh Huyền	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
9b19cc3c-f300-4781-a73b-b373b8f24847	Nguyễn Phạm Quốc Hưng	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
df08dfd9-9a83-41fa-8ed7-f01960559561	Nguyễn Đào Viết Khánh	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
a9ba48be-efc0-402b-aa7f-5465d26f8749	Nguyễn Nguyễn Quang Kiên	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
b40de8d1-a7bb-4234-af37-f70bbd312f98	Nguyễn Nguyễn Khánh Linh	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
bc6b90e0-0f7e-4ecd-ac00-ac424b642382	Nguyễn Nguyễn Phi Long	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
8cbc8802-3047-4a50-9718-bb4cb5497ea5	Nguyễn Trần Đức Lương	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
6aebad65-5482-43c7-a872-8a2ae1e37887	Nguyễn Hồ Thị Khánh Ly	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
591c8f3e-c58d-41a8-8013-a95c39d32be1	Nguyễn Nguyễn Hoàng Bảo Minh	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
ff40f5d1-97eb-4e8f-9773-f4fe946f5673	Nguyễn Hồ Thu Nga	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
06f55b6b-1215-48d3-b898-2b793c8ef351	Nguyễn Trịnh Thị Hằng Nga	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
8e3f766f-f9ab-418f-a6f0-2ad5c696acef	Nguyễn Nguyễn Lục Ngạn	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
e0855af1-dc89-4b04-bc24-bec2fc4aaaea	Nguyễn Lê Hoàng Mỹ Ngọc	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
2d178df2-bada-4e95-b869-7de5c22af7e3	Nguyễn Lê Thị Bảo Ngọc	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
62bc5766-394d-42f3-b1ca-15ffe2edb83e	Nguyễn Cao Anh Nhân	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
4a0bf389-6332-40c9-9e4d-1227b92efadb	Nguyễn Lê Võ Thanh Nhật	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
0d872ff0-9bf5-4efe-9a63-b0da17a43007	Nguyễn Đặng Thị Thu Phương	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
5a4a5b1a-90b7-4ed3-9b90-8022bb26d590	Nguyễn Đỗ Bảo Quang	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
a80d6b09-b87a-4918-aa9a-cf74f5670883	Nguyễn Hồ Hữu Quang	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
d520621d-2e9f-4e7e-91d5-19a859dc9959	Nguyễn Hô Khắc Anh Quân	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
6f158e53-b314-4ced-9009-bafe80c329b7	Nguyễn Hồ Sỹ Quân	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
e7e229de-32dc-4052-8918-1ee2202b733f	Nguyễn Phạm Vũ Như Quỳnh	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
cdd16880-6c58-4107-8459-20162e5d7eed	Nguyễn Nguyễn Ngọc Lan Thanh	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
7e82a5e3-7a71-45cc-ab8e-eab0355c9851	Nguyễn Võ Hạnh Thảo	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
a1d2036b-04f5-4b69-bbff-7c307537da23	Nguyễn Trần Hồng Thế	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
4b1eed5d-1efc-4215-a212-f49d509cce5e	Nguyễn Dương Đức Thịnh	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
8ed53903-837b-4503-a0ad-181ef0dc03d8	Nguyễn Phan Ngọc Thịnh	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
f069bd55-e1b2-426d-b52d-8b16d5d7023e	Nguyễn Bùi Thị Lý Thu	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
4ef68cfe-c972-4833-96f1-f62067704c47	Nguyễn Hồ Nguyễn Khánh Trang	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
3c956010-c5a2-4df0-a1f6-b9fd62d4fdb0	Nguyễn Hồ Thị Thùy Trang	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
7572c3de-2528-4729-8184-761cfc433609	Nguyễn Lê Thị Thùy Trang	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
b1b91def-da08-41ee-8bc5-c85fe8058754	Nguyễn Nguyễn Thị Huyền Trang	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
43404e6a-14b2-460e-8caf-46dd6f742884	Nguyễn Nguyễn Trần Huyền Trang	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
04560129-f759-4e4d-8342-a217b739ddad	Nguyễn Nguyễn Quốc Trọng	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
e3295b80-07c6-4519-8a76-eeaed1827032	Nguyễn Đoàn Tường Vy	20/10/2026	Nam	Kinh	\N	t	\N	24/03/2025	\N	\N	2026-08-07 05:59:59.699054+00	e639da07-0722-4433-818f-a750d3353739	Xã ABC - tỉnh ABC - Việt Nam	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 05:59:59.699054+00
\.


--
-- Data for Name: dotptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."dotptdoanvien" ("id", "namhoc", "hocky", "tendot", "tungay", "denngay", "isdefault", "islocked", "ghichu", "updatedat", "createdat") FROM stdin;
\.


--
-- Data for Name: duytricsdl; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."duytricsdl" ("id", "so", "thoigian", "createdat", "updatedat") FROM stdin;
ab945a0f-764b-4f95-ad2c-346fcac6f297	64	2026-08-07 05:44:20.196987+00	2026-08-07 05:44:20.196987+00	2026-08-10 09:16:32.109195+00
\.


--
-- Data for Name: github_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."github_settings" ("id", "github_repo_path", "github_branch", "github_workflow_file", "github_restore_workflow_file", "github_token", "updated_at", "updated_by", "createdat", "updatedat") FROM stdin;
project_02	congty/du_an_backend	main	supabase-backup.yml	supabase-restore.yml	ghp_abc123...	2026-08-07 05:44:20.196987+00	\N	2026-08-07 05:44:20.196987+00	2026-08-07 05:44:20.196987+00
default	hohuuthe/gialaithpthuynhthuckhang	main	supabase-backup.yml	supabase-restore.yml	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	2026-08-07 06:12:04.031+00	Admin	2026-08-07 06:06:52.06384+00	2026-08-07 06:12:03.384108+00
\.


--
-- Data for Name: namhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."namhoc" ("id", "tennamhoc", "islocked", "updatedat", "createdat", "isdefault") FROM stdin;
e639da07-0722-4433-818f-a750d3353739	2026-2027	f	2026-08-07 05:55:56.647639+00	2026-08-07 05:55:56.647639+00	f
\.


--
-- Data for Name: phancong; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phancong" ("id", "hocky", "tuan", "lopcham", "chamlop", "updatedat", "namhoc", "createdat") FROM stdin;
a1e8446b-cc46-4090-8152-1f348897af54	HK1	1	bb3e746f-9312-415f-91af-5fcaa9ce3c51	772448cc-0db5-4bac-9293-5449db6e99e3	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
e242afd2-0f58-4f1d-b6f2-810882807254	HK1	1	772448cc-0db5-4bac-9293-5449db6e99e3	d8a38395-9ad2-4d0f-8649-a114ec4c974e	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
15c0b17a-254c-487c-951d-0b2f43fda4b1	HK1	1	d8a38395-9ad2-4d0f-8649-a114ec4c974e	17a28646-06e1-47f8-b21c-49c0e42754a1	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
832b111b-aca6-4068-9a7e-384ff241edf6	HK1	1	17a28646-06e1-47f8-b21c-49c0e42754a1	8d5cfa83-2f15-4847-8c87-6e74e2dc28ba	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
2cdd1a43-1b9b-4dc3-a48d-e45d88333e36	HK1	1	8d5cfa83-2f15-4847-8c87-6e74e2dc28ba	d1c422d6-a9f9-43a1-b08f-a818237eea37	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
e4d73f3a-5d4b-4898-a2d3-5a5a62c3eda6	HK1	1	d1c422d6-a9f9-43a1-b08f-a818237eea37	8faee1f2-fb95-4156-89a9-ec369571503a	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
08e4c1d9-e17a-4ae3-8ad5-282e8f08cb88	HK1	1	8faee1f2-fb95-4156-89a9-ec369571503a	35cb0914-de8e-4ced-a8b4-6b7315411e75	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
b82474c3-8543-4c28-90ea-12263d72ffd1	HK1	1	35cb0914-de8e-4ced-a8b4-6b7315411e75	81bc51cd-ccc1-43fb-a5a9-52997e1b9478	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
b92afe05-97ce-4d64-a2e6-01d02759cc6f	HK1	1	81bc51cd-ccc1-43fb-a5a9-52997e1b9478	81c093e6-f7ea-43dd-b2d7-2d5e3c21aa07	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
89448513-60fc-4079-867d-4c9686f8e32c	HK1	1	81c093e6-f7ea-43dd-b2d7-2d5e3c21aa07	54ed61b7-a227-4277-98dd-6173db4367e3	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
920de087-cf28-40bd-9a7b-b98198d7d01c	HK1	1	54ed61b7-a227-4277-98dd-6173db4367e3	a0f9553c-d742-4640-bcc5-8e2b685a96a2	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
1c9f36ea-91cf-43d9-abf0-64d2ce068e08	HK1	1	a0f9553c-d742-4640-bcc5-8e2b685a96a2	8ed5365e-4c16-4bd2-8ea9-cd62a9f12d84	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
b4f91e0d-2556-48e3-8082-fad8b7069f0c	HK1	1	8ed5365e-4c16-4bd2-8ea9-cd62a9f12d84	27c996d4-203f-46cd-87e9-b092edccaf3d	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
ff4544f4-cace-4a42-9d0b-c45112bb869a	HK1	1	27c996d4-203f-46cd-87e9-b092edccaf3d	9981dac0-b398-45a4-848b-342a438bb69d	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
b08ce2c7-350b-45bf-a039-c0018b3e2b68	HK1	1	9981dac0-b398-45a4-848b-342a438bb69d	1bd08cd2-441f-46d1-b296-659d435b9af0	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
9aa18398-a703-4d41-94af-bc034f56be6f	HK1	1	1bd08cd2-441f-46d1-b296-659d435b9af0	b3422f59-4ee0-4793-97e1-d45486f099db	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
04e6059e-76dd-40cf-afd5-4c27c949192a	HK1	1	b3422f59-4ee0-4793-97e1-d45486f099db	90e032a7-9444-44f2-b695-ce8320c9dd8b	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
76fa0851-b3db-4a8f-8c46-f3b558a0375e	HK1	1	90e032a7-9444-44f2-b695-ce8320c9dd8b	f091a001-1b8b-4fad-99b0-f9b2ca30b203	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
9f98947d-322c-4a81-bf7f-02151ed0d81c	HK1	1	f091a001-1b8b-4fad-99b0-f9b2ca30b203	c2a4b148-3823-4c50-a9b5-9c28585f6287	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
22925aa6-2067-4d4b-85c3-22440a899be1	HK1	1	c2a4b148-3823-4c50-a9b5-9c28585f6287	d5b97c4f-c5be-4c65-9e3a-5994ec9928ef	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
e9f5f7c0-0359-4122-9993-85dfd6aba8bd	HK1	1	d5b97c4f-c5be-4c65-9e3a-5994ec9928ef	ef697039-bd8f-4c64-b13e-5c43e293cb56	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
7dcac2b1-ce55-4c8c-af87-ed017cc05c34	HK1	1	ef697039-bd8f-4c64-b13e-5c43e293cb56	f334293f-6084-42c2-a86c-3ce9931d4178	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
b6561e4a-052c-4de2-8db7-bca0b8370bb6	HK1	1	f334293f-6084-42c2-a86c-3ce9931d4178	2ea11633-e790-4614-9247-29bf67cefcf5	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
a4bcd68c-6ea5-4911-8020-929fcd43bc83	HK1	1	2ea11633-e790-4614-9247-29bf67cefcf5	118eaa3d-5966-4d58-a546-dd90e898ec09	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
758662e8-a314-42f5-9e2f-be0107a189eb	HK1	1	118eaa3d-5966-4d58-a546-dd90e898ec09	2e05f4e7-a9dd-4509-bb18-0811778fe125	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
894033ce-befb-4c35-a760-e47a9d2a4de2	HK1	1	2e05f4e7-a9dd-4509-bb18-0811778fe125	c40a71fb-cb2b-4e18-8350-29012c7626e6	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
7d3695ed-b344-486a-ba8b-fc8a34b25c2a	HK1	1	c40a71fb-cb2b-4e18-8350-29012c7626e6	b93634ed-056f-4783-a702-868c5060918e	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
36d6a57e-2303-4317-bcb7-0dcbc6d7b6d5	HK1	1	b93634ed-056f-4783-a702-868c5060918e	c94c47a3-245a-41f2-8963-65b8daddf235	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
23b7c17c-4cf3-4da5-a032-820db92fd764	HK1	1	c94c47a3-245a-41f2-8963-65b8daddf235	2af14773-0698-49bd-9a9b-3e68142650ac	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
ddb05e6f-08aa-417c-8fce-e15e8edceefe	HK1	1	2af14773-0698-49bd-9a9b-3e68142650ac	fd7cf163-d24e-465c-917a-a8909be5f5ea	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
2800fada-b354-4007-b561-1c1278911d76	HK1	1	fd7cf163-d24e-465c-917a-a8909be5f5ea	6878280e-b7a7-47b3-a676-40a6f97fba68	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
b01ba604-ae8a-4c7f-91e8-d2dcd323d20c	HK1	1	6878280e-b7a7-47b3-a676-40a6f97fba68	0973641c-cb3a-4e5b-8992-b2f5c061ac1e	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
3f828ab6-7685-41b1-83c4-930e305f48a7	HK1	1	0973641c-cb3a-4e5b-8992-b2f5c061ac1e	bb3e746f-9312-415f-91af-5fcaa9ce3c51	2026-08-07 06:00:31.568686+00	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:31.568686+00
\.


--
-- Data for Name: phanquyen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phanquyen" ("id", "doi_tuong", "tab_chuc_nang", "ngay_cap_nhat", "nam_hoc", "createdat", "updatedat", "quyen_xem", "quyen_them", "quyen_sua", "quyen_xoa", "giai_thich") FROM stdin;
\.


--
-- Data for Name: ptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ptdoanvien" ("id", "doanvien_id", "dotdangki", "thongkerenluyen", "diemrenluyen", "pheduyet", "createdat", "updatedat", "namhoc", "soquyetdinh", "ngayquyetdinh") FROM stdin;
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."push_subscriptions" ("id", "user_id", "role", "chidoan_id", "subscription", "endpoint", "created_at") FROM stdin;
\.


--
-- Data for Name: ql_baocao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ql_baocao" ("id", "chu_de", "chu_de_phu", "tu_ngay", "den_ngay", "cho_phep_minh_chung", "doi_tuong_nop", "huong_dan", "ngay_tao", "nam_hoc_id", "hoc_ky", "config_noi_dung1", "config_noi_dung2", "config_noi_dung3", "config_noi_dung4", "config_noi_dung5", "config_noi_dung6", "config_noi_dung7", "config_noi_dung8", "config_noi_dung9", "config_noi_dung10", "allowed_file_types", "max_file_size") FROM stdin;
\.


--
-- Data for Name: ql_nop_bc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ql_nop_bc" ("id", "ql_bao_cao_id", "doanvien_id", "noi_dung1", "noi_dung2", "noi_dung3", "noi_dung4", "noi_dung5", "noi_dung6", "noi_dung7", "noi_dung8", "noi_dung9", "noi_dung10", "duong_dan_minh_chung", "ghi_chu", "trang_thai", "ngay_capnhat", "chi_doan_id", "danh_sach_anh", "vaitro_nop", "doituong_nop", "nguoi_tao_id") FROM stdin;
\.


--
-- Data for Name: qlchidoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."qlchidoan" ("id", "tenchidoan", "buoihoc", "ban", "phonghoc", "bithu", "gvcn", "namhoc", "updatedat", "createdat") FROM stdin;
bb3e746f-9312-415f-91af-5fcaa9ce3c51	10A1	Chiều	TN	11	Nguyễn Khánh Linh	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
772448cc-0db5-4bac-9293-5449db6e99e3	10A2	Chiều	TN	10	Lê Hồ Hoài An	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
d8a38395-9ad2-4d0f-8649-a114ec4c974e	10A3	Chiều	TN	9	Nguyễn Thị Trâm Anh	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
17a28646-06e1-47f8-b21c-49c0e42754a1	10A4	Chiều	TN	8	Phạm Hà Anh	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
8d5cfa83-2f15-4847-8c87-6e74e2dc28ba	10A5	Chiều	XH	7	Nguyễn Thị Minh Hằng	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
d1c422d6-a9f9-43a1-b08f-a818237eea37	10A6	Chiều	XH	1	\N	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
8faee1f2-fb95-4156-89a9-ec369571503a	10A7	Chiều	XH	2	Phạm Khánh Chi	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
35cb0914-de8e-4ced-a8b4-6b7315411e75	10A8	Chiều	XH	3	\N	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
81bc51cd-ccc1-43fb-a5a9-52997e1b9478	10A9	Chiều	XH	4	\N	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
81c093e6-f7ea-43dd-b2d7-2d5e3c21aa07	10A10	Chiều	XH	5	Hồ Thị Ngọc Trâm	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
54ed61b7-a227-4277-98dd-6173db4367e3	10A11	Chiều	XH	6	\N	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
a0f9553c-d742-4640-bcc5-8e2b685a96a2	11C1	Chiều	TN	12	Lê Minh Phương	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
8ed5365e-4c16-4bd2-8ea9-cd62a9f12d84	11C2	Chiều	TN	13	Nguyễn Thị Yến Nhi	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
27c996d4-203f-46cd-87e9-b092edccaf3d	11C3	Chiều	TN	14	Phạm Minh Anh	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
9981dac0-b398-45a4-848b-342a438bb69d	11C4	Chiều	TN	15	Cù Hoàng Gia An	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
1bd08cd2-441f-46d1-b296-659d435b9af0	11C5	Chiều	TN	16	\N	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
b3422f59-4ee0-4793-97e1-d45486f099db	11C6	Sáng	XH	1	Vũ Đỗ Thùy Lâm	Trần Thị Huệ	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
90e032a7-9444-44f2-b695-ce8320c9dd8b	11C7	Sáng	XH	2	nguyễn hồng lai	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
f091a001-1b8b-4fad-99b0-f9b2ca30b203	11C8	Sáng	XH	3	Nguyễn Trung Hiếu	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
c2a4b148-3823-4c50-a9b5-9c28585f6287	11C9	Sáng	XH	4	\N	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
d5b97c4f-c5be-4c65-9e3a-5994ec9928ef	11C10	Sáng	XH	5	Nguyễn Ngọc Tiên Nhi	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
ef697039-bd8f-4c64-b13e-5c43e293cb56	11C11	Sáng	XH	6	Bùi Thị Tường Vy	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
f334293f-6084-42c2-a86c-3ce9931d4178	11C12	Sáng	XH	7	Nguyễn Thị Ngọc Hân	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
2ea11633-e790-4614-9247-29bf67cefcf5	12B1	Sáng	TN	8	Phạm Ngọc Gia Hân	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
118eaa3d-5966-4d58-a546-dd90e898ec09	12B2	Sáng	TN	9	Hoàng Thị Thu Huyền	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
2e05f4e7-a9dd-4509-bb18-0811778fe125	12B3	Sáng	TN	10	Nguyễn Gia Hân	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
c40a71fb-cb2b-4e18-8350-29012c7626e6	12B4	Sáng	TN	11	\N	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
b93634ed-056f-4783-a702-868c5060918e	12B5	Sáng	XH	12	Hoàng Thị Quỳnh Chi	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
c94c47a3-245a-41f2-8963-65b8daddf235	12B6	Sáng	XH	13	Nguyễn Thanh Phương	Nguyễn Thị Thảo Trinh	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
2af14773-0698-49bd-9a9b-3e68142650ac	12B7	Sáng	XH	14	Trần Lê Ngọc Khánh	Võ Thị Bình	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
fd7cf163-d24e-465c-917a-a8909be5f5ea	12B8	Sáng	XH	15	Quế Trân	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
6878280e-b7a7-47b3-a676-40a6f97fba68	12B9	Sáng	XH	16	Thành Tín	\N	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
0973641c-cb3a-4e5b-8992-b2f5c061ac1e	12B10	Sáng	XH	17	Lê Tiến Công	Đoàn Thị Minh Hương	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:59:44.598747+00	2026-08-07 05:59:44.598747+00
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."settings" ("id", "title1", "title2", "diemsan", "aiprompttemplate", "geminiapikey", "diemsanhocky", "aiassistantprompt", "thongbaochamdiem", "doituongthongbao", "noidungthongbao", "thongbaodoanvien", "autopenaltytime", "autopenaltypoints", "autopenaltycriteria", "autopenaltyenabled", "autopenaltyreporter", "autopenaltyday", "thongbaophattriendoan", "excel_header_left", "excel_header_right", "excel_footer_left", "excel_footer_right", "word_header_left", "word_header_right", "word_footer_left", "word_footer_right", "namhoc", "createdat", "updatedat", "cloudinary_cloud_name", "cloudinary_upload_preset", "cloudinary_api_key", "cloudinary_api_secret", "r2_account_id", "r2_access_key_id", "r2_secret_access_key", "r2_bucket_name", "r2_custom_domain", "show_class_select_gvcn") FROM stdin;
29013205-6355-4a47-b5b6-66751158cbed	HỆ THỐNG QUẢN LÝ THI ĐUA	Đoàn trường THPT Huỳnh Thúc Kháng	0		AQ.Ab8RN6IpdNcqygmfhTPYGYOGFISdfmx9J2-CzxnOMy4ToCnSSQ	0		\N	\N	\N	\N	23:55	30	Lỗi không báo cáo điểm tuần	f	Hệ thống tự động	0		[C]ĐOÀN XÃ ĐỨC CƠ\n[C][B]ĐOÀN TRƯỜNG THPT LÊ HOÀN\n[C]***\n[C]Số:        -BC/ĐTN	[U][C][B]ĐOÀN TNCS HỒ CHÍ MINH\n\n[C][I]Đức Cơ, {{FULL_DATE}}	[C][B]NGƯỜI LẬP BIỂU\n[C][I](Ký và ghi rõ họ tên)\n\n\n\n[C]{{HOTEN}}	[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ\n\n\n\n[C][B]{{HOTEN}}	[C]ĐOÀN XÃ ĐỨC CƠ\n[C][B]ĐOÀN TRƯỜNG THPT LÊ HOÀN\n[C]***\n[C]Số:        -BC/ĐTN	[C][B]ĐOÀN TNCS HỒ CHÍ MINH\n\n[C][I]Đức Cơ, {{FULL_DATE}}	[L][B]NƠI NHẬN:\n[L]- Như Điều 1;\n[L]- Lưu VT.	[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ\n\n\n\n[C][B]{{HOTEN}}	e639da07-0722-4433-818f-a750d3353739	2026-08-07 05:58:48.506756+00	2026-08-07 06:05:21.742996+00					775e1277d9c26fb01333229090205770	e734377dd5a65d86464fc06aa26d207b	14a385c773ee9d0466d2a21fca6c3a371609699d9e0de40a88d47e160428a7b1	gialaithpthuynhthuckhang	https://pub-4b307cab27584ade9591272c0f69a8a3.r2.dev	Không hiển thị
\.


--
-- Data for Name: taikhoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."taikhoan" ("id", "username", "password", "fullname", "role", "updatedat", "chidoan_id", "createdat", "doanvien_id", "sl_dangnhap", "tg_truycap") FROM stdin;
858d7bfc-0d6d-4898-b5b3-7c080195ca79	Admin	$argon2id$v=19$m=65536,t=3,p=4$PUDXJllthdBNREj7Jd2KTw$blk3GJ2W6Jk/+OxXqPO9quBJtU9mjQqcHb6rYNmBxjM	Quản trị	Admin	2026-08-07 06:06:02.919683+00	\N	2026-08-07 05:44:20.196987+00	\N	2	2026-08-07 13:06:03+00
\.


--
-- Data for Name: theodoi360; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."theodoi360" ("id", "nguoi_to_cao_id", "doan_vien_vi_pham_id", "tieu_chi_id", "chi_tiet_vi_pham", "danh_sach_hinh_anh", "url_video", "trang_thai", "nam_hoc_id", "tuan_id", "ngay_vi_pham", "ngay_tao", "hoc_ky", "phan_hoi_bi_to_cao", "phan_hoi_lop", "minh_chung_drive") FROM stdin;
\.


--
-- Data for Name: thongbao_hethong; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."thongbao_hethong" ("id", "title", "content", "sender", "target_role", "target_chidoan_id", "target_user_id", "created_at", "read_by") FROM stdin;
\.


--
-- Data for Name: thongbao_riengbiet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."thongbao_riengbiet" ("id", "namhoc_id", "sender_id", "sender_name", "sender_role", "title", "content", "attachments", "target_roles", "target_chidoan_ids", "start_at", "end_at", "created_at", "updated_at", "read_by") FROM stdin;
\.


--
-- Data for Name: tieuchitd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tieuchitd" ("id", "matieuchi", "tentieuchi", "mota", "loaitieuchi", "diemtru", "diemcong", "ghichu", "updatedat", "hocky", "namhoc", "createdat") FROM stdin;
5aa3f36b-0a6c-4a73-b282-56ebe7064d2c	CD01	Điểm 10		Thành tích	0	3		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
c22fd2d6-242e-4833-8f4c-7b140671c1a7	CD02	Điểm 9		Thành tích	0	2		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
90e3a8f6-621f-406c-b8d3-715ba5cf21fd	CD03	Nhặt được của rơi		Thành tích	0	5		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
d2b5e30c-74e7-4e9c-9291-6cc8ded71911	TC01	Đi học muộn2		Vi phạm	2	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
70c6afd9-48f7-4d56-b949-1ed926ab7adf	TC02	Cúp tiết		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
20bd01f7-652e-417e-87d0-256b981a6684	TC03	Cúp chào cờ		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
4b7c1b68-d5ed-4790-8623-1fc8a15fe6ca	TC04	Trốn sinh hoạt 15p		Vi phạm	2	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
2dda1f2a-df41-4e5e-b888-c8828bc1b0fc	TC05	Ở ngoài khi trống vào lớp		Vi phạm	2	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
44600779-57ae-4397-b3f8-ecc862e83df3	TC06	Không sơ vin		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
c9a3b2f6-fbd0-4af0-a7dd-8a7869607ece	TC07	Không bảng tên		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
199f8b57-6376-4f81-a91d-a15094fbd816	TC08	Sai đồng phục		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
5fc3ce3f-ddb9-4d0a-ad6d-294051638064	TC09	Không đeo huy hiệu đoàn		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
894f77a1-9a5f-4c88-bd4e-e2064063dde6	TC10	Không quai dép		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
b5661ab0-1ca8-4967-b705-6962fe940e9f	TC11	Đi dép lê		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
6d8c6fee-ebb2-476f-a579-5502877c7966	TC12	Để tóc dài, nhuộm, uốn, tóc cắt không đúng qui định đối với nam		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
b0cfed03-14ea-4736-a511-f36cbef1ea43	TC13	Học sinh nữ nhuộm tóc, trang điểm, đối với học sinh nữ đeo quá 1 cái/tai và sỏ khuyên ở các vị trí khác ngoài tai.		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
79f94f65-3c44-40d1-bf8b-3e0b1c6656d1	TC14	Học sinh nam đeo hoa tai		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
947eae76-3cbf-4d94-adf7-74b4afc84182	TC15	Sơn móng tay		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
a779497c-9669-4c0f-aa03-12f4a66a0572	TC16	Mặc áo khoác ngoài		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
fd6fa13c-aa41-457c-b3a6-bef1fc4d1fff	TC17	Không đội mũ bảo hiểm		Vi phạm	30	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
b3f130b5-4679-4aaf-bc8b-488447ac7c3c	TC18	chở quá số người qui định		Vi phạm	30	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
307c4bb6-f161-4002-a095-5b30757c480f	TC19	đi xe phân khối lớn đến trường		Vi phạm	30	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
6c5551a5-dcf5-4fc6-9723-fe0cc4fb2a9a	TC20	Học sinh để xe không đúng quy định		Vi phạm	10	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
a1258873-678f-440b-b505-ede155afcdd6	TC21	Hút thuốc lá		Vi phạm	30	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
bca4daa6-ec27-410d-833d-ef9d584ab2de	TC22	Tham gia gây gỗ đánh nhau		Vi phạm	30	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
25494f65-5cd1-4f22-b81c-b21bdb87f690	TC23	Mang hung khí, tàng trữ, sử dụng các chất kích thích gây nghiện, gây cháy nổ, các vật dụng nguy hiểm		Vi phạm	30	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
be577226-e21b-4bc4-a24f-4229b2a69c66	TC24	Có thái độ vô lễ với CB, CNV nhà trường:		Vi phạm	30	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
1579c2eb-3a6d-46a8-8f39-228e8461dc1b	TC25	Học sinh có thái độ không chuẩn mực (lời nói, hành động) với CBGV, NV và bạn học		Vi phạm	10	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
9b110c33-641b-4e69-a077-abaeffe709c2	TC26	Vệ sinh muộn		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
d89dec56-469a-4ec0-ae73-fefc748d9e11	TC27	Lớp trực nhật bẩn		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
420547bf-dbe6-4872-8a8e-3de79749e141	TC28	Học sinh vứt rác không đúng qui định		Vi phạm	10	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
c4504c9a-6a9c-43b4-9e40-206c21d84b4b	TC29	Mang quà vặt lên lớp		Vi phạm	10	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
9494dd6d-bb66-4680-9588-9bcc60ce39d7	TC30	Không sinh hoạt 15’ đầu giờ		Vi phạm	10	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
ae6f6466-88ac-4184-a37a-abfac47237bc	TC31	Không sinh hoạt chi đoàn cuối tháng		Vi phạm	10	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
14d56ac8-c799-468e-a8c2-18ee8fd44ecb	TC32	Không cất ghế ngồi chào cờ		Vi phạm	10	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
2863ea0c-a654-4c40-9222-a7cd8d4b4486	TC33	Xếp hàng chào cờ chậm hoặc không đúng qui định		Vi phạm	10	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
4f71607a-6a03-49c5-b0d3-7752f4ed9779	TC34	Đối với các bài thi do cấp trên phát động		Vi phạm	1	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
cc7eb74e-b5f5-464b-b9fe-5e4e5deff031	TC35	Vắng học không có lý do		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
4ef5ca2f-9e52-44cd-a6fe-8c485f6b14f0	TC36	Học sinh vào lớp muộn trong giữa các tiết học		Vi phạm	0.5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
1d933e06-1e90-408e-b374-fee7494c75f6	TC37	Học sinh không nghiêm túc trong giờ học		Vi phạm	3	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
f59c896f-651d-435d-9d23-e8fdd165f384	TC38	Lớp không tham gia trực cổng		Vi phạm	2	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
4c649fc2-8fb5-43ae-9bc5-549dbb0a03d7	TC39	Lớp không tham gia trực 15p		Vi phạm	2	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
6a250978-07b7-4935-9160-6104cf150ef7	TC40	Đi chấm trễ		Vi phạm	2	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
bdd6f89e-7314-43f9-bf16-48a08f2dd162	TC41	Vắng học có lí do (1 tiết)		Vi phạm	0.25	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
30224105-e427-4a24-a2da-932fdedfa1f3	TC42	Vắng học có lí do (2 tiết)		Vi phạm	0.5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
87a3d625-f744-48a6-af3d-f288a6b790b7	TC43	Vắng học có lí do (3 tiết)		Vi phạm	0.75	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
53c01957-a3af-4638-ab70-c7fedb9a12ae	TC44	Vắng học có lí do (4 tiết)		Vi phạm	1	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
e62dafea-30ab-4c02-a924-49fc901d626e	TC45	Vắng học có lí do (5 tiết)		Vi phạm	1.25	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
27362baa-69d5-4763-80fb-2af324eb3c97	TC46	Mang ĐT lên trường		Vi phạm	30	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
388acc4b-d8b7-4348-863d-9442b931d2f4	TC48	Vắng học trên 3 buổi		Vi phạm	0	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
b1c64185-23c9-4e85-8678-365b4a74d9cf	TC49	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.		Vi phạm	0	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
52fd9fb6-bb31-4f56-a068-d193e9c2dc94	TC50	mang đồ ăn/ nước uống (trừ sữa, nước lọc) hoặc ăn/ uống trong lớp.	mang đồ ăn/ nước uống (trừ sữa, nước lọc) hoặc ăn/ uống trong lớp.	Vi phạm	10	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
41c26fa7-ae4c-48b7-b3e1-40403764629e	TC51	Lỗi không báo cáo điểm tuần		Vi phạm	30	0	Hệ thống tự trừ	2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
e76a39ba-f553-4c1c-95e0-deda42bd5103	TC52	Không đi chấm		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
8caa72db-88a2-4484-a3ef-f738d81e8ad9	TC53	Trực cầu thang bẩn		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
c5184500-a4e4-4a8d-b67f-5662a38aff07	TC56	Cúp 1 tiết		Vi phạm	5	0		2026-08-07 06:00:16.639773+00	HK1	e639da07-0722-4433-818f-a750d3353739	2026-08-07 06:00:16.639773+00
\.


--
-- Data for Name: tuanhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tuanhoc" ("id", "namhoc", "hocky", "tuan", "tungay", "denngay", "isdefault", "islocked", "createdat", "ghichu", "updatedat") FROM stdin;
7016181a-3a26-4399-b67e-796b13888431	e639da07-0722-4433-818f-a750d3353739	HK1	1	2026-08-03	2026-12-25	t	f	2026-08-07 05:57:13.474223+00		2026-08-07 05:57:28.930371+00
\.


--
-- Data for Name: messages_2026_08_06; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_06" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_07; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_07" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_08; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_08" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_09; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_09" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_10; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_10" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."schema_migrations" ("version", "inserted_at") FROM stdin;
20211116024918	2026-08-07 03:58:14
20211116045059	2026-08-07 03:58:14
20211116050929	2026-08-07 03:58:14
20211116051442	2026-08-07 03:58:14
20211116212300	2026-08-07 03:58:14
20211116213355	2026-08-07 03:58:14
20211116213934	2026-08-07 03:58:14
20211116214523	2026-08-07 03:58:14
20211122062447	2026-08-07 03:58:14
20211124070109	2026-08-07 03:58:14
20211202204204	2026-08-07 03:58:14
20211202204605	2026-08-07 03:58:14
20211210212804	2026-08-07 03:58:14
20211228014915	2026-08-07 03:58:14
20220107221237	2026-08-07 03:58:14
20220228202821	2026-08-07 03:58:14
20220312004840	2026-08-07 03:58:14
20220603231003	2026-08-07 03:58:14
20220603232444	2026-08-07 03:58:14
20220615214548	2026-08-07 03:58:14
20220712093339	2026-08-07 03:58:14
20220908172859	2026-08-07 03:58:14
20220916233421	2026-08-07 03:58:14
20230119133233	2026-08-07 03:58:14
20230128025114	2026-08-07 03:58:14
20230128025212	2026-08-07 03:58:14
20230227211149	2026-08-07 03:58:14
20230228184745	2026-08-07 03:58:14
20230308225145	2026-08-07 03:58:14
20230328144023	2026-08-07 03:58:14
20231018144023	2026-08-07 03:58:14
20231204144023	2026-08-07 03:58:14
20231204144024	2026-08-07 03:58:14
20231204144025	2026-08-07 03:58:14
20240108234812	2026-08-07 03:58:14
20240109165339	2026-08-07 03:58:14
20240227174441	2026-08-07 03:58:14
20240311171622	2026-08-07 03:58:14
20240321100241	2026-08-07 03:58:14
20240401105812	2026-08-07 03:58:14
20240418121054	2026-08-07 03:58:14
20240523004032	2026-08-07 03:58:14
20240618124746	2026-08-07 03:58:14
20240801235015	2026-08-07 03:58:14
20240805133720	2026-08-07 03:58:14
20240827160934	2026-08-07 03:58:14
20240919163303	2026-08-07 03:58:14
20240919163305	2026-08-07 03:58:14
20241019105805	2026-08-07 03:58:14
20241030150047	2026-08-07 03:58:14
20241108114728	2026-08-07 03:58:14
20241121104152	2026-08-07 03:58:14
20241130184212	2026-08-07 03:58:14
20241220035512	2026-08-07 03:58:14
20241220123912	2026-08-07 03:58:14
20241224161212	2026-08-07 03:58:14
20250107150512	2026-08-07 03:58:14
20250110162412	2026-08-07 03:58:14
20250123174212	2026-08-07 03:58:14
20250128220012	2026-08-07 03:58:14
20250506224012	2026-08-07 03:58:14
20250523164012	2026-08-07 03:58:14
20250714121412	2026-08-07 03:58:14
20250905041441	2026-08-07 03:58:14
20251103001201	2026-08-07 03:58:14
20251120212548	2026-08-07 03:58:14
20251120215549	2026-08-07 03:58:14
20260218120000	2026-08-07 03:58:14
20260326120000	2026-08-07 03:58:14
20260514120000	2026-08-07 03:58:14
20260527120000	2026-08-07 03:58:14
20260528120000	2026-08-07 03:58:14
20260603120000	2026-08-07 03:58:14
20260605120000	2026-08-07 03:58:14
20260606110000	2026-08-07 03:58:14
20260616120000	2026-08-07 03:58:14
20260624120000	2026-08-07 03:58:14
20260626120000	2026-08-07 03:58:14
20260706120000	2026-08-07 03:58:14
20260707120000	2026-08-07 03:58:14
20260709120000	2026-08-07 03:58:14
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."subscription" ("id", "subscription_id", "entity", "filters", "claims", "created_at", "action_filter", "selected_columns") FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type") FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_analytics" ("name", "type", "format", "created_at", "updated_at", "id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_vectors" ("id", "type", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."migrations" ("id", "name", "hash", "executed_at") FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-08-07 03:58:17.225599
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-08-07 03:58:17.270058
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-08-07 03:58:17.273986
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-08-07 03:58:17.300377
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-08-07 03:58:17.312279
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-08-07 03:58:17.31635
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-08-07 03:58:17.321644
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-08-07 03:58:17.326037
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-08-07 03:58:17.33002
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-08-07 03:58:17.334081
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-08-07 03:58:17.338127
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-08-07 03:58:17.342228
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-08-07 03:58:17.347624
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-08-07 03:58:17.351635
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-08-07 03:58:17.355541
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-08-07 03:58:17.384778
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-08-07 03:58:17.390282
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-08-07 03:58:17.394376
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-08-07 03:58:17.398567
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-08-07 03:58:17.404449
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-08-07 03:58:17.409755
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-08-07 03:58:17.418306
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-08-07 03:58:17.433451
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-08-07 03:58:17.444541
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-08-07 03:58:17.449124
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-08-07 03:58:17.453328
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-08-07 03:58:17.459811
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-08-07 03:58:17.463429
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-08-07 03:58:17.466956
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-08-07 03:58:17.470385
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-08-07 03:58:17.473778
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-08-07 03:58:17.477351
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-08-07 03:58:17.481242
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-08-07 03:58:17.484961
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-08-07 03:58:17.488545
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-08-07 03:58:17.492135
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-08-07 03:58:17.496206
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-08-07 03:58:17.50371
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-08-07 03:58:17.509264
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-08-07 03:58:17.521294
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-08-07 03:58:17.525034
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-08-07 03:58:17.528639
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-08-07 03:58:17.532342
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-08-07 03:58:17.535823
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-08-07 03:58:17.539461
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-08-07 03:58:17.543929
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-08-07 03:58:17.556027
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-08-07 03:58:17.56053
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-08-07 03:58:17.564435
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-08-07 03:58:17.585106
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-08-07 03:58:17.589686
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-08-07 03:58:17.607771
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-08-07 03:58:17.609695
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-08-07 03:58:17.619576
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-08-07 03:58:17.622428
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-08-07 03:58:17.624166
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-08-07 03:58:17.629078
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-08-07 03:58:17.636284
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-08-07 03:58:17.640364
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-08-07 03:58:17.645337
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-08-07 03:58:17.650163
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata", "version", "owner_id", "user_metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads" ("id", "in_progress_size", "upload_signature", "bucket_id", "key", "version", "owner_id", "created_at", "user_metadata", "metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads_parts" ("id", "upload_id", "size", "part_number", "bucket_id", "key", "etag", "owner_id", "version", "created_at") FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."vector_indexes" ("id", "name", "bucket_id", "data_type", "dimension", "distance_metric", "metadata_configuration", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY "vault"."secrets" ("id", "name", "description", "secret", "key_id", "nonce", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 9, true);


--
-- Name: phanquyen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."phanquyen_id_seq"', 1, false);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_realtime_admin
--

SELECT pg_catalog.setval('"realtime"."subscription_id_seq"', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "amr_id_pk" PRIMARY KEY ("id");


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."audit_log_entries"
    ADD CONSTRAINT "audit_log_entries_pkey" PRIMARY KEY ("id");


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_identifier_key" UNIQUE ("identifier");


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_pkey" PRIMARY KEY ("id");


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."flow_state"
    ADD CONSTRAINT "flow_state_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_provider_id_provider_unique" UNIQUE ("provider_id", "provider");


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."instances"
    ADD CONSTRAINT "instances_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_authentication_method_pkey" UNIQUE ("session_id", "authentication_method");


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_last_challenged_at_key" UNIQUE ("last_challenged_at");


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_code_key" UNIQUE ("authorization_code");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_id_key" UNIQUE ("authorization_id");


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_client_states"
    ADD CONSTRAINT "oauth_client_states_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_clients"
    ADD CONSTRAINT "oauth_clients_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_client_unique" UNIQUE ("user_id", "client_id");


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_token_unique" UNIQUE ("token");


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_entity_id_key" UNIQUE ("entity_id");


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_pkey" PRIMARY KEY ("id");


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_pkey" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_pkey" PRIMARY KEY ("id");


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_pkey" PRIMARY KEY ("id");


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_providers"
    ADD CONSTRAINT "sso_providers_pkey" PRIMARY KEY ("id");


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_phone_key" UNIQUE ("phone");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_pkey" PRIMARY KEY ("id");


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_pkey" PRIMARY KEY ("id");


--
-- Name: chamdiem chamdiem_pkey2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_pkey2" PRIMARY KEY ("id");


--
-- Name: doanvien doanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_pkey" PRIMARY KEY ("id");


--
-- Name: dotptdoanvien dotptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "dotptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: duytricsdl duytricsdl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."duytricsdl"
    ADD CONSTRAINT "duytricsdl_pkey" PRIMARY KEY ("id");


--
-- Name: github_settings github_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."github_settings"
    ADD CONSTRAINT "github_settings_pkey" PRIMARY KEY ("id");


--
-- Name: namhoc namhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."namhoc"
    ADD CONSTRAINT "namhoc_pkey" PRIMARY KEY ("id");


--
-- Name: phancong phancong_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_pkey" PRIMARY KEY ("id");


--
-- Name: phanquyen phanquyen_doi_tuong_tab_namhoc_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_doi_tuong_tab_namhoc_unique" UNIQUE ("doi_tuong", "tab_chuc_nang", "nam_hoc");


--
-- Name: phanquyen phanquyen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_pkey" PRIMARY KEY ("id");


--
-- Name: ptdoanvien ptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "ptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: push_subscriptions push_subscriptions_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."push_subscriptions"
    ADD CONSTRAINT "push_subscriptions_endpoint_key" UNIQUE ("endpoint");


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."push_subscriptions"
    ADD CONSTRAINT "push_subscriptions_pkey" PRIMARY KEY ("id");


--
-- Name: ql_baocao ql_baocao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_baocao"
    ADD CONSTRAINT "ql_baocao_pkey" PRIMARY KEY ("id");


--
-- Name: ql_nop_bc ql_nop_bc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "ql_nop_bc_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_ten_nam_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_ten_nam_unique" UNIQUE ("tenchidoan", "namhoc");


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "settings_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_username_key" UNIQUE ("username");


--
-- Name: theodoi360 theodoi360_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_pkey" PRIMARY KEY ("id");


--
-- Name: thongbao_hethong thongbao_hethong_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."thongbao_hethong"
    ADD CONSTRAINT "thongbao_hethong_pkey" PRIMARY KEY ("id");


--
-- Name: thongbao_riengbiet thongbao_riengbiet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."thongbao_riengbiet"
    ADD CONSTRAINT "thongbao_riengbiet_pkey" PRIMARY KEY ("id");


--
-- Name: tieuchitd tieuchitd_matieuchi_namhoc_hocky_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_matieuchi_namhoc_hocky_unique" UNIQUE ("matieuchi", "namhoc", "hocky");


--
-- Name: tieuchitd tieuchitd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_pkey" PRIMARY KEY ("id");


--
-- Name: tuanhoc tuanhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "tuanhoc_pkey" PRIMARY KEY ("id");


--
-- Name: chamdiem unique_chamdiem_record; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "unique_chamdiem_record" UNIQUE ("namhoc", "hocky", "tuan", "thu", "ngay", "lopcham", "chamlop", "doanvienid", "matieuchi", "tentieuchi", "loaitieuchi", "diemtru", "diemcong", "chidoan_id");


--
-- Name: qlchidoan unique_namhoc_tenchidoan; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "unique_namhoc_tenchidoan" UNIQUE ("namhoc", "tenchidoan");


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages"
    ADD CONSTRAINT "messages_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_06 messages_2026_08_06_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_06"
    ADD CONSTRAINT "messages_2026_08_06_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_07 messages_2026_08_07_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_07"
    ADD CONSTRAINT "messages_2026_08_07_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_08 messages_2026_08_08_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_08"
    ADD CONSTRAINT "messages_2026_08_08_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_09 messages_2026_08_09_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_09"
    ADD CONSTRAINT "messages_2026_08_09_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_10 messages_2026_08_10_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_10"
    ADD CONSTRAINT "messages_2026_08_10_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages"
    ADD CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL))) NOT VALID;


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."subscription"
    ADD CONSTRAINT "pk_subscription" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_analytics"
    ADD CONSTRAINT "buckets_analytics_pkey" PRIMARY KEY ("id");


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets"
    ADD CONSTRAINT "buckets_pkey" PRIMARY KEY ("id");


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_vectors"
    ADD CONSTRAINT "buckets_vectors_pkey" PRIMARY KEY ("id");


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_name_key" UNIQUE ("name");


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_pkey" PRIMARY KEY ("id");


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_pkey" PRIMARY KEY ("id");


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_pkey" PRIMARY KEY ("id");


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "audit_logs_instance_id_idx" ON "auth"."audit_log_entries" USING "btree" ("instance_id");


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "confirmation_token_idx" ON "auth"."users" USING "btree" ("confirmation_token") WHERE (("confirmation_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_created_at_idx" ON "auth"."custom_oauth_providers" USING "btree" ("created_at");


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_enabled_idx" ON "auth"."custom_oauth_providers" USING "btree" ("enabled");


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_identifier_idx" ON "auth"."custom_oauth_providers" USING "btree" ("identifier");


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_provider_type_idx" ON "auth"."custom_oauth_providers" USING "btree" ("provider_type");


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_current_idx" ON "auth"."users" USING "btree" ("email_change_token_current") WHERE (("email_change_token_current")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_new_idx" ON "auth"."users" USING "btree" ("email_change_token_new") WHERE (("email_change_token_new")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "factor_id_created_at_idx" ON "auth"."mfa_factors" USING "btree" ("user_id", "created_at");


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "flow_state_created_at_idx" ON "auth"."flow_state" USING "btree" ("created_at" DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_email_idx" ON "auth"."identities" USING "btree" ("email" "text_pattern_ops");


--
-- Name: INDEX "identities_email_idx"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."identities_email_idx" IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_user_id_idx" ON "auth"."identities" USING "btree" ("user_id");


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_auth_code" ON "auth"."flow_state" USING "btree" ("auth_code");


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_oauth_client_states_created_at" ON "auth"."oauth_client_states" USING "btree" ("created_at");


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_user_id_auth_method" ON "auth"."flow_state" USING "btree" ("user_id", "authentication_method");


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_created_at_desc" ON "auth"."users" USING "btree" ("created_at" DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_email" ON "auth"."users" USING "btree" ("email");


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_last_sign_in_at_desc" ON "auth"."users" USING "btree" ("last_sign_in_at" DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_name" ON "auth"."users" USING "btree" ((("raw_user_meta_data" ->> 'name'::"text"))) WHERE (("raw_user_meta_data" ->> 'name'::"text") IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_challenge_created_at_idx" ON "auth"."mfa_challenges" USING "btree" ("created_at" DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "mfa_factors_user_friendly_name_unique" ON "auth"."mfa_factors" USING "btree" ("friendly_name", "user_id") WHERE (TRIM(BOTH FROM "friendly_name") <> ''::"text");


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_factors_user_id_idx" ON "auth"."mfa_factors" USING "btree" ("user_id");


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_auth_pending_exp_idx" ON "auth"."oauth_authorizations" USING "btree" ("expires_at") WHERE ("status" = 'pending'::"auth"."oauth_authorization_status");


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_clients_deleted_at_idx" ON "auth"."oauth_clients" USING "btree" ("deleted_at");


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_client_idx" ON "auth"."oauth_consents" USING "btree" ("client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_user_client_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_user_order_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "granted_at" DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_relates_to_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("relates_to");


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_token_hash_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("token_hash");


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "one_time_tokens_user_id_token_type_key" ON "auth"."one_time_tokens" USING "btree" ("user_id", "token_type");


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "reauthentication_token_idx" ON "auth"."users" USING "btree" ("reauthentication_token") WHERE (("reauthentication_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "recovery_token_idx" ON "auth"."users" USING "btree" ("recovery_token") WHERE (("recovery_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id");


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_user_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id", "user_id");


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_parent_idx" ON "auth"."refresh_tokens" USING "btree" ("parent");


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_session_id_revoked_idx" ON "auth"."refresh_tokens" USING "btree" ("session_id", "revoked");


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_updated_at_idx" ON "auth"."refresh_tokens" USING "btree" ("updated_at" DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_providers_sso_provider_id_idx" ON "auth"."saml_providers" USING "btree" ("sso_provider_id");


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_created_at_idx" ON "auth"."saml_relay_states" USING "btree" ("created_at" DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_for_email_idx" ON "auth"."saml_relay_states" USING "btree" ("for_email");


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_sso_provider_id_idx" ON "auth"."saml_relay_states" USING "btree" ("sso_provider_id");


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_not_after_idx" ON "auth"."sessions" USING "btree" ("not_after" DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_oauth_client_id_idx" ON "auth"."sessions" USING "btree" ("oauth_client_id");


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_user_id_idx" ON "auth"."sessions" USING "btree" ("user_id");


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_domains_domain_idx" ON "auth"."sso_domains" USING "btree" ("lower"("domain"));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_domains_sso_provider_id_idx" ON "auth"."sso_domains" USING "btree" ("sso_provider_id");


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_providers_resource_id_idx" ON "auth"."sso_providers" USING "btree" ("lower"("resource_id"));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_providers_resource_id_pattern_idx" ON "auth"."sso_providers" USING "btree" ("resource_id" "text_pattern_ops");


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "unique_phone_factor_per_user" ON "auth"."mfa_factors" USING "btree" ("user_id", "phone");


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "user_id_created_at_idx" ON "auth"."sessions" USING "btree" ("user_id", "created_at");


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "users_email_partial_key" ON "auth"."users" USING "btree" ("email") WHERE ("is_sso_user" = false);


--
-- Name: INDEX "users_email_partial_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."users_email_partial_key" IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_email_idx" ON "auth"."users" USING "btree" ("instance_id", "lower"(("email")::"text"));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_idx" ON "auth"."users" USING "btree" ("instance_id");


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_is_anonymous_idx" ON "auth"."users" USING "btree" ("is_anonymous");


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_expires_at_idx" ON "auth"."webauthn_challenges" USING "btree" ("expires_at");


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_user_id_idx" ON "auth"."webauthn_challenges" USING "btree" ("user_id");


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "webauthn_credentials_credential_id_key" ON "auth"."webauthn_credentials" USING "btree" ("credential_id");


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_credentials_user_id_idx" ON "auth"."webauthn_credentials" USING "btree" ("user_id");


--
-- Name: idx_activity_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_created_at" ON "public"."activity_logs" USING "btree" ("created_at" DESC);


--
-- Name: idx_activity_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_user_id" ON "public"."activity_logs" USING "btree" ("user_id");


--
-- Name: idx_chamdiem_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_chamlop" ON "public"."chamdiem" USING "btree" ("chamlop");


--
-- Name: idx_chamdiem_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_chidoan_id" ON "public"."chamdiem" USING "btree" ("chidoan_id");


--
-- Name: idx_chamdiem_doanvienid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_doanvienid" ON "public"."chamdiem" USING "btree" ("doanvienid");


--
-- Name: idx_chamdiem_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_hocky" ON "public"."chamdiem" USING "btree" ("hocky");


--
-- Name: idx_chamdiem_loaitieuchi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_loaitieuchi" ON "public"."chamdiem" USING "btree" ("loaitieuchi");


--
-- Name: idx_chamdiem_lopcham_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_lopcham_chamlop" ON "public"."chamdiem" USING "btree" ("lopcham", "chamlop");


--
-- Name: idx_chamdiem_optimization_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_chamlop" ON "public"."chamdiem" USING "btree" ("chamlop");


--
-- Name: idx_chamdiem_optimization_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_chidoan_id" ON "public"."chamdiem" USING "btree" ("chidoan_id");


--
-- Name: idx_chamdiem_optimization_namhoc_hocky_tuan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_namhoc_hocky_tuan" ON "public"."chamdiem" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_chamdiem_optimization_namhoc_tuan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_namhoc_tuan" ON "public"."chamdiem" USING "btree" ("namhoc", "tuan");


--
-- Name: idx_chamdiem_thongke; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_thongke" ON "public"."chamdiem" USING "btree" ("namhoc", "hocky", "tuan", "chamlop");


--
-- Name: idx_doanvien_chidoan_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_chidoan_namhoc" ON "public"."doanvien" USING "btree" ("chidoan_id", "namhoc");


--
-- Name: idx_doanvien_hoten; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_hoten" ON "public"."doanvien" USING "btree" ("hoten");


--
-- Name: idx_doanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_namhoc" ON "public"."doanvien" USING "btree" ("namhoc");


--
-- Name: idx_dotptdoanvien_nam_hk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_dotptdoanvien_nam_hk" ON "public"."dotptdoanvien" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_namhoc_isdefault_true; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_namhoc_isdefault_true" ON "public"."namhoc" USING "btree" ("isdefault") WHERE ("isdefault" = true);


--
-- Name: idx_phancong_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_chamlop" ON "public"."phancong" USING "btree" ("chamlop");


--
-- Name: idx_phancong_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_context" ON "public"."phancong" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_phancong_lopcham; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_lopcham" ON "public"."phancong" USING "btree" ("lopcham");


--
-- Name: idx_phanquyen_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phanquyen_namhoc" ON "public"."phanquyen" USING "btree" ("nam_hoc");


--
-- Name: idx_ptdoanvien_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_doanvien" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: idx_ptdoanvien_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_doanvien_id" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: idx_ptdoanvien_dot; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_dot" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: idx_ptdoanvien_dotdangki; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_dotdangki" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: idx_ptdoanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_namhoc" ON "public"."ptdoanvien" USING "btree" ("namhoc");


--
-- Name: idx_ql_nop_bc_baocao; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ql_nop_bc_baocao" ON "public"."ql_nop_bc" USING "btree" ("ql_bao_cao_id");


--
-- Name: idx_ql_nop_bc_chidoan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ql_nop_bc_chidoan" ON "public"."ql_nop_bc" USING "btree" ("chi_doan_id");


--
-- Name: idx_ql_nop_bc_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ql_nop_bc_doanvien" ON "public"."ql_nop_bc" USING "btree" ("doanvien_id");


--
-- Name: idx_qlchidoan_optimization_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_qlchidoan_optimization_namhoc" ON "public"."qlchidoan" USING "btree" ("namhoc");


--
-- Name: idx_settings_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_settings_namhoc" ON "public"."settings" USING "btree" ("namhoc");


--
-- Name: idx_taikhoan_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_doanvien_id" ON "public"."taikhoan" USING "btree" ("doanvien_id");


--
-- Name: idx_taikhoan_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_role" ON "public"."taikhoan" USING "btree" ("role");


--
-- Name: idx_taikhoan_username_lower; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_username_lower" ON "public"."taikhoan" USING "btree" ("lower"("username"));


--
-- Name: idx_theodoi360_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_theodoi360_doanvien" ON "public"."theodoi360" USING "btree" ("doan_vien_vi_pham_id");


--
-- Name: idx_theodoi360_namhoc_tuan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_theodoi360_namhoc_tuan" ON "public"."theodoi360" USING "btree" ("nam_hoc_id", "tuan_id");


--
-- Name: idx_tieuchitd_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tieuchitd_context" ON "public"."tieuchitd" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_tuan_isdefault_true; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_tuan_isdefault_true" ON "public"."tuanhoc" USING "btree" ("isdefault") WHERE ("isdefault" = true);


--
-- Name: idx_tuanhoc_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_context" ON "public"."tuanhoc" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_tuanhoc_optimization_namhoc_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_optimization_namhoc_hocky" ON "public"."tuanhoc" USING "btree" ("namhoc", "hocky");


--
-- Name: ngay_3_5_idx_ptdoanvien_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_doanvien_id" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: ngay_3_5_idx_ptdoanvien_dotdangki; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_dotdangki" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "ix_realtime_subscription_entity" ON "realtime"."subscription" USING "btree" ("entity");


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_inserted_at_topic_index" ON ONLY "realtime"."messages" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_06_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_06_inserted_at_topic_idx" ON "realtime"."messages_2026_08_06" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_07_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_07_inserted_at_topic_idx" ON "realtime"."messages_2026_08_07" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_08_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_08_inserted_at_topic_idx" ON "realtime"."messages_2026_08_08" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_09_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_09_inserted_at_topic_idx" ON "realtime"."messages_2026_08_09" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_10_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_10_inserted_at_topic_idx" ON "realtime"."messages_2026_08_10" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE UNIQUE INDEX "subscription_subscription_id_entity_filters_action_filter_selec" ON "realtime"."subscription" USING "btree" ("subscription_id", "entity", "filters", "action_filter", COALESCE("selected_columns", '{}'::"text"[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bname" ON "storage"."buckets" USING "btree" ("name");


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bucketid_objname" ON "storage"."objects" USING "btree" ("bucket_id", "name");


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "buckets_analytics_unique_name_idx" ON "storage"."buckets_analytics" USING "btree" ("name") WHERE ("deleted_at" IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_multipart_uploads_list" ON "storage"."s3_multipart_uploads" USING "btree" ("bucket_id", "key", "created_at");


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name" ON "storage"."objects" USING "btree" ("bucket_id", "name" COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name_lower" ON "storage"."objects" USING "btree" ("bucket_id", "lower"("name") COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "name_prefix_search" ON "storage"."objects" USING "btree" ("name" "text_pattern_ops");


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "vector_indexes_name_bucket_id_idx" ON "storage"."vector_indexes" USING "btree" ("name", "bucket_id");


--
-- Name: messages_2026_08_06_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_06_inserted_at_topic_idx";


--
-- Name: messages_2026_08_06_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_06_pkey";


--
-- Name: messages_2026_08_07_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_07_inserted_at_topic_idx";


--
-- Name: messages_2026_08_07_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_07_pkey";


--
-- Name: messages_2026_08_08_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_08_inserted_at_topic_idx";


--
-- Name: messages_2026_08_08_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_08_pkey";


--
-- Name: messages_2026_08_09_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_09_inserted_at_topic_idx";


--
-- Name: messages_2026_08_09_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_09_pkey";


--
-- Name: messages_2026_08_10_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_10_inserted_at_topic_idx";


--
-- Name: messages_2026_08_10_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_10_pkey";


--
-- Name: qlchidoan trigger_chi_doan_deletion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trigger_chi_doan_deletion" AFTER DELETE ON "public"."qlchidoan" FOR EACH ROW EXECUTE FUNCTION "public"."handle_chi_doan_deletion"();


--
-- Name: chamdiem update_chamdiem_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_chamdiem_modtime" BEFORE UPDATE ON "public"."chamdiem" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: doanvien update_doanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_doanvien_modtime" BEFORE UPDATE ON "public"."doanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: dotptdoanvien update_dotptdoanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_dotptdoanvien_modtime" BEFORE UPDATE ON "public"."dotptdoanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: duytricsdl update_duytricsdl_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_duytricsdl_modtime" BEFORE UPDATE ON "public"."duytricsdl" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: github_settings update_github_settings_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_github_settings_modtime" BEFORE UPDATE ON "public"."github_settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: namhoc update_namhoc_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_namhoc_modtime" BEFORE UPDATE ON "public"."namhoc" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: phancong update_phancong_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_phancong_modtime" BEFORE UPDATE ON "public"."phancong" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: phanquyen update_phanquyen_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_phanquyen_modtime" BEFORE UPDATE ON "public"."phanquyen" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: ptdoanvien update_ptdoanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_ptdoanvien_modtime" BEFORE UPDATE ON "public"."ptdoanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: qlchidoan update_qlchidoan_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_qlchidoan_modtime" BEFORE UPDATE ON "public"."qlchidoan" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: settings update_settings_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_settings_modtime" BEFORE UPDATE ON "public"."settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: taikhoan update_taikhoan_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_taikhoan_modtime" BEFORE UPDATE ON "public"."taikhoan" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: tieuchitd update_tieuchitd_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_tieuchitd_modtime" BEFORE UPDATE ON "public"."tieuchitd" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: tuanhoc update_tuanhoc_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_tuanhoc_modtime" BEFORE UPDATE ON "public"."tuanhoc" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TRIGGER "tr_check_filters" BEFORE INSERT OR UPDATE ON "realtime"."subscription" FOR EACH ROW EXECUTE FUNCTION "realtime"."subscription_check_filters"();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "enforce_bucket_name_length_trigger" BEFORE INSERT OR UPDATE OF "name" ON "storage"."buckets" FOR EACH ROW EXECUTE FUNCTION "storage"."enforce_bucket_name_length"();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_buckets_delete" BEFORE DELETE ON "storage"."buckets" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_objects_delete" BEFORE DELETE ON "storage"."objects" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "update_objects_updated_at" BEFORE UPDATE ON "storage"."objects" FOR EACH ROW EXECUTE FUNCTION "storage"."update_updated_at_column"();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_auth_factor_id_fkey" FOREIGN KEY ("factor_id") REFERENCES "auth"."mfa_factors"("id") ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_flow_state_id_fkey" FOREIGN KEY ("flow_state_id") REFERENCES "auth"."flow_state"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_oauth_client_id_fkey" FOREIGN KEY ("oauth_client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_doanvien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_doanvien_id_fkey" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_dotdangki_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_dotdangki_fkey" FOREIGN KEY ("dotdangki") REFERENCES "public"."dotptdoanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_namhoc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_namhoc_fkey" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id");


--
-- Name: chamdiem chamdiem_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_doanvienid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_doanvienid_fkey" FOREIGN KEY ("doanvienid") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doanvien doanvien_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem fk_chamdiem_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "fk_chamdiem_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doanvien fk_doanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "fk_doanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dotptdoanvien fk_dotptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "fk_dotptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong fk_phancong_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "fk_phancong_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phanquyen fk_phanquyen_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "fk_phanquyen_namhoc" FOREIGN KEY ("nam_hoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien fk_ptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "fk_ptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ql_baocao fk_ql_baocao_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_baocao"
    ADD CONSTRAINT "fk_ql_baocao_namhoc" FOREIGN KEY ("nam_hoc_id") REFERENCES "public"."namhoc"("id");


--
-- Name: ql_nop_bc fk_ql_nop_bc_baocao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "fk_ql_nop_bc_baocao" FOREIGN KEY ("ql_bao_cao_id") REFERENCES "public"."ql_baocao"("id") ON DELETE CASCADE;


--
-- Name: ql_nop_bc fk_ql_nop_bc_chidoan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "fk_ql_nop_bc_chidoan" FOREIGN KEY ("chi_doan_id") REFERENCES "public"."qlchidoan"("id") ON DELETE SET NULL;


--
-- Name: ql_nop_bc fk_ql_nop_bc_doanvien; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "fk_ql_nop_bc_doanvien" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON DELETE CASCADE;


--
-- Name: qlchidoan fk_qlchidoan_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "fk_qlchidoan_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: settings fk_settings_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "fk_settings_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tieuchitd fk_tieuchitd_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "fk_tieuchitd_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tuanhoc fk_tuanhoc_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "fk_tuanhoc_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: taikhoan taikhoan_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: taikhoan taikhoan_doanvien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_doanvien_id_fkey" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON DELETE SET NULL;


--
-- Name: theodoi360 theodoi360_doan_vien_vi_pham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_doan_vien_vi_pham_fkey" FOREIGN KEY ("doan_vien_vi_pham_id") REFERENCES "public"."doanvien"("id");


--
-- Name: theodoi360 theodoi360_nam_hoc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_nam_hoc_fkey" FOREIGN KEY ("nam_hoc_id") REFERENCES "public"."namhoc"("id");


--
-- Name: theodoi360 theodoi360_nguoi_to_cao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_nguoi_to_cao_fkey" FOREIGN KEY ("nguoi_to_cao_id") REFERENCES "public"."doanvien"("id");


--
-- Name: theodoi360 theodoi360_tieu_chi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_tieu_chi_fkey" FOREIGN KEY ("tieu_chi_id") REFERENCES "public"."tieuchitd"("id");


--
-- Name: theodoi360 theodoi360_tuan_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_tuan_fkey" FOREIGN KEY ("tuan_id") REFERENCES "public"."tuanhoc"("id");


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_upload_id_fkey" FOREIGN KEY ("upload_id") REFERENCES "storage"."s3_multipart_uploads"("id") ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets_vectors"("id");


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."audit_log_entries" ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."flow_state" ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."identities" ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."instances" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_amr_claims" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_challenges" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_factors" ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."one_time_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."refresh_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_relay_states" ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."schema_migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sessions" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_domains" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."users" ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_logs Admins can view all activity logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can view all activity logs" ON "public"."activity_logs" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."taikhoan"
  WHERE (("taikhoan"."id" = "auth"."uid"()) AND ("taikhoan"."role" = 'Admin'::"text")))));


--
-- Name: theodoi360 Allow authenticated users to DELETE; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow authenticated users to DELETE" ON "public"."theodoi360" FOR DELETE TO "authenticated" USING (true);


--
-- Name: theodoi360 Allow authenticated users to INSERT; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow authenticated users to INSERT" ON "public"."theodoi360" FOR INSERT TO "authenticated" WITH CHECK (true);


--
-- Name: theodoi360 Allow authenticated users to SELECT; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow authenticated users to SELECT" ON "public"."theodoi360" FOR SELECT TO "authenticated" USING (true);


--
-- Name: theodoi360 Allow authenticated users to UPDATE; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow authenticated users to UPDATE" ON "public"."theodoi360" FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: ql_baocao Allow full access for authenticated users; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow full access for authenticated users" ON "public"."ql_baocao" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: ql_nop_bc Allow full access for authenticated users on ql_nop_bc; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow full access for authenticated users on ql_nop_bc" ON "public"."ql_nop_bc" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: activity_logs Authenticated users can insert activity logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users can insert activity logs" ON "public"."activity_logs" FOR INSERT TO "authenticated" WITH CHECK (true);


--
-- Name: chamdiem Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."chamdiem" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: doanvien Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."doanvien" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: dotptdoanvien Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."dotptdoanvien" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: namhoc Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."namhoc" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: phancong Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."phancong" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: phanquyen Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."phanquyen" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: ptdoanvien Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."ptdoanvien" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: qlchidoan Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."qlchidoan" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: settings Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."settings" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: taikhoan Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."taikhoan" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: tieuchitd Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."tieuchitd" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: tuanhoc Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."tuanhoc" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: github_settings Cho phép Admin quản lý cấu hình github; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép Admin quản lý cấu hình github" ON "public"."github_settings" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."taikhoan"
  WHERE (("taikhoan"."id" = "auth"."uid"()) AND ("taikhoan"."role" = 'Admin'::"text"))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."taikhoan"
  WHERE (("taikhoan"."id" = "auth"."uid"()) AND ("taikhoan"."role" = 'Admin'::"text")))));


--
-- Name: push_subscriptions Cho phép DELETE push_subscriptions khi đã đăng nhập; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép DELETE push_subscriptions khi đã đăng nhập" ON "public"."push_subscriptions" FOR DELETE USING (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: thongbao_hethong Cho phép DELETE thongbao_hethong khi đã đăng nhập; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép DELETE thongbao_hethong khi đã đăng nhập" ON "public"."thongbao_hethong" FOR DELETE USING (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: push_subscriptions Cho phép INSERT push_subscriptions khi đã đăng nhập; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép INSERT push_subscriptions khi đã đăng nhập" ON "public"."push_subscriptions" FOR INSERT WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: thongbao_hethong Cho phép INSERT thongbao_hethong khi đã đăng nhập; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép INSERT thongbao_hethong khi đã đăng nhập" ON "public"."thongbao_hethong" FOR INSERT WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: push_subscriptions Cho phép SELECT push_subscriptions khi đã đăng nhập; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép SELECT push_subscriptions khi đã đăng nhập" ON "public"."push_subscriptions" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: thongbao_hethong Cho phép SELECT thongbao_hethong khi đã đăng nhập; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép SELECT thongbao_hethong khi đã đăng nhập" ON "public"."thongbao_hethong" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: push_subscriptions Cho phép UPDATE push_subscriptions khi đã đăng nhập; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép UPDATE push_subscriptions khi đã đăng nhập" ON "public"."push_subscriptions" FOR UPDATE USING (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: thongbao_hethong Cho phép UPDATE thongbao_hethong khi đã đăng nhập; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép UPDATE thongbao_hethong khi đã đăng nhập" ON "public"."thongbao_hethong" FOR UPDATE USING (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: duytricsdl Cho phép cập nhật dữ liệu công khai; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép cập nhật dữ liệu công khai" ON "public"."duytricsdl" FOR UPDATE USING (true) WITH CHECK (true);


--
-- Name: thongbao_riengbiet Cho phép cập nhật thông báo; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép cập nhật thông báo" ON "public"."thongbao_riengbiet" FOR UPDATE USING (true) WITH CHECK (true);


--
-- Name: namhoc Cho phép người dùng xác thực có toàn quyền bảng n; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép người dùng xác thực có toàn quyền bảng n" ON "public"."namhoc" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: github_settings Cho phép người dùng đã đăng nhập thao tác github_se; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép người dùng đã đăng nhập thao tác github_se" ON "public"."github_settings" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: thongbao_riengbiet Cho phép thêm thông báo; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép thêm thông báo" ON "public"."thongbao_riengbiet" FOR INSERT WITH CHECK (true);


--
-- Name: thongbao_riengbiet Cho phép tất cả người dùng đọc thông báo; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép tất cả người dùng đọc thông báo" ON "public"."thongbao_riengbiet" FOR SELECT USING (true);


--
-- Name: thongbao_riengbiet Cho phép xóa thông báo; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép xóa thông báo" ON "public"."thongbao_riengbiet" FOR DELETE USING (true);


--
-- Name: namhoc Cho phép đọc công khai bảng namhoc; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép đọc công khai bảng namhoc" ON "public"."namhoc" FOR SELECT USING (true);


--
-- Name: duytricsdl Cho phép đọc dữ liệu công khai; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép đọc dữ liệu công khai" ON "public"."duytricsdl" FOR SELECT USING (true);


--
-- Name: duytricsdl Chỉ cho phép thêm khi đã đăng nhập; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ cho phép thêm khi đã đăng nhập" ON "public"."duytricsdl" FOR INSERT TO "authenticated" WITH CHECK (true);


--
-- Name: duytricsdl Chỉ cho phép xóa khi đã đăng nhập; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ cho phép xóa khi đã đăng nhập" ON "public"."duytricsdl" FOR DELETE TO "authenticated" USING (true);


--
-- Name: taikhoan Enable read access for all users; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Enable read access for all users" ON "public"."taikhoan" FOR SELECT USING (true);


--
-- Name: activity_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."activity_logs" ENABLE ROW LEVEL SECURITY;

--
-- Name: chamdiem; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."chamdiem" ENABLE ROW LEVEL SECURITY;

--
-- Name: doanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."doanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: dotptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."dotptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: duytricsdl; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."duytricsdl" ENABLE ROW LEVEL SECURITY;

--
-- Name: github_settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."github_settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: namhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."namhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: phancong; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phancong" ENABLE ROW LEVEL SECURITY;

--
-- Name: phanquyen; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ENABLE ROW LEVEL SECURITY;

--
-- Name: ptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: push_subscriptions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."push_subscriptions" ENABLE ROW LEVEL SECURITY;

--
-- Name: ql_baocao; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ql_baocao" ENABLE ROW LEVEL SECURITY;

--
-- Name: ql_nop_bc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ql_nop_bc" ENABLE ROW LEVEL SECURITY;

--
-- Name: qlchidoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."qlchidoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: taikhoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."taikhoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: theodoi360; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."theodoi360" ENABLE ROW LEVEL SECURITY;

--
-- Name: thongbao_hethong; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."thongbao_hethong" ENABLE ROW LEVEL SECURITY;

--
-- Name: thongbao_riengbiet; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."thongbao_riengbiet" ENABLE ROW LEVEL SECURITY;

--
-- Name: tieuchitd; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tieuchitd" ENABLE ROW LEVEL SECURITY;

--
-- Name: tuanhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tuanhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_analytics" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_vectors" ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."objects" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads_parts" ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."vector_indexes" ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION "supabase_realtime" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";

--
-- Name: supabase_realtime_messages_publication; Type: PUBLICATION; Schema: -; Owner: supabase_admin
--

CREATE PUBLICATION "supabase_realtime_messages_publication" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime_messages_publication" OWNER TO "supabase_admin";

--
-- Name: supabase_realtime_messages_publication messages; Type: PUBLICATION TABLE; Schema: realtime; Owner: supabase_admin
--

ALTER PUBLICATION "supabase_realtime_messages_publication" ADD TABLE ONLY "realtime"."messages";


--
-- Name: SCHEMA "auth"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "auth" TO "anon";
GRANT USAGE ON SCHEMA "auth" TO "authenticated";
GRANT USAGE ON SCHEMA "auth" TO "service_role";
GRANT ALL ON SCHEMA "auth" TO "supabase_auth_admin";
GRANT ALL ON SCHEMA "auth" TO "dashboard_user";
GRANT USAGE ON SCHEMA "auth" TO "postgres";


--
-- Name: SCHEMA "extensions"; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA "extensions" TO "anon";
GRANT USAGE ON SCHEMA "extensions" TO "authenticated";
GRANT USAGE ON SCHEMA "extensions" TO "service_role";
GRANT ALL ON SCHEMA "extensions" TO "dashboard_user";


--
-- Name: SCHEMA "public"; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";


--
-- Name: SCHEMA "realtime"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "realtime" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "realtime" TO "anon";
GRANT USAGE ON SCHEMA "realtime" TO "service_role";
GRANT ALL ON SCHEMA "realtime" TO "supabase_realtime_admin" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "realtime" TO "authenticated";


--
-- Name: SCHEMA "storage"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "storage" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "storage" TO "anon";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
GRANT ALL ON SCHEMA "storage" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON SCHEMA "storage" TO "dashboard_user";


--
-- Name: SCHEMA "vault"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "vault" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "vault" TO "service_role";


--
-- Name: FUNCTION "email"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."email"() TO "dashboard_user";


--
-- Name: FUNCTION "jwt"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."jwt"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."jwt"() TO "dashboard_user";


--
-- Name: FUNCTION "role"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."role"() TO "dashboard_user";


--
-- Name: FUNCTION "uid"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."uid"() TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."armor"("bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea", "text"[], "text"[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "dashboard_user";


--
-- Name: FUNCTION "crypt"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."crypt"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "dearmor"("text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."dearmor"("text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "dashboard_user";


--
-- Name: FUNCTION "decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "decrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "digest"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."digest"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "digest"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."digest"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "encrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "encrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "gen_random_bytes"(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "dashboard_user";


--
-- Name: FUNCTION "gen_random_uuid"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_random_uuid"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "dashboard_user";


--
-- Name: FUNCTION "gen_salt"("text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_salt"("text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "dashboard_user";


--
-- Name: FUNCTION "gen_salt"("text", integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_salt"("text", integer) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_cron_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."grant_pg_graphql_access"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "grant_pg_net_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_net_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_key_id"("bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgrst_ddl_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_ddl_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgrst_drop_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_drop_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."set_graphql_placeholder"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "uuid_generate_v1"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v1"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v1mc"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v3"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v4"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v4"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v5"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "uuid_nil"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_nil"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_dns"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_dns"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_oid"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_oid"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_url"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_url"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_x500"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_x500"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "dashboard_user";


--
-- Name: FUNCTION "graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb"); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "postgres";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "pg_reload_conf"(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "pg_catalog"."pg_reload_conf"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "get_auth"("p_usename" "text"); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") TO "pgbouncer";


--
-- Name: FUNCTION "handle_chi_doan_deletion"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "service_role";


--
-- Name: FUNCTION "handle_post_like"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "service_role";


--
-- Name: FUNCTION "handle_update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "service_role";


--
-- Name: TABLE "taikhoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."taikhoan" TO "anon";
GRANT ALL ON TABLE "public"."taikhoan" TO "authenticated";
GRANT ALL ON TABLE "public"."taikhoan" TO "service_role";


--
-- Name: FUNCTION "rpc_get_user_by_username"("p_username" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "service_role";


--
-- Name: FUNCTION "update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "service_role";


--
-- Name: FUNCTION "update_modified_column"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "service_role";


--
-- Name: FUNCTION "apply_rls"("wal" "jsonb", "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "anon";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "service_role";


--
-- Name: FUNCTION "broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "dashboard_user";


--
-- Name: FUNCTION "build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "service_role";


--
-- Name: FUNCTION "cast"("val" "text", "type_" "regtype"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "anon";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "service_role";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "service_role";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "anon";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "service_role";


--
-- Name: FUNCTION "is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "service_role";


--
-- Name: FUNCTION "list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "dashboard_user";


--
-- Name: FUNCTION "quote_wal2json"("entity" "regclass"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "anon";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "service_role";


--
-- Name: FUNCTION "send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "subscription_check_filters"(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "anon";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "service_role";


--
-- Name: FUNCTION "to_regrole"("role_name" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "service_role";


--
-- Name: FUNCTION "topic"(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."topic"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."topic"() TO "dashboard_user";


--
-- Name: FUNCTION "wal2json_escape_identifier"("name" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "service_role";


--
-- Name: FUNCTION "create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";


--
-- Name: FUNCTION "update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";


--
-- Name: TABLE "audit_log_entries"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."audit_log_entries" TO "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "custom_oauth_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "postgres";
GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "dashboard_user";


--
-- Name: TABLE "flow_state"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."flow_state" TO "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."flow_state" TO "dashboard_user";


--
-- Name: TABLE "identities"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."identities" TO "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."identities" TO "dashboard_user";


--
-- Name: TABLE "instances"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."instances" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."instances" TO "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "mfa_amr_claims"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_amr_claims" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_amr_claims" TO "dashboard_user";


--
-- Name: TABLE "mfa_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_challenges" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_challenges" TO "dashboard_user";


--
-- Name: TABLE "mfa_factors"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_factors" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_factors" TO "dashboard_user";


--
-- Name: TABLE "oauth_authorizations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "dashboard_user";


--
-- Name: TABLE "oauth_client_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_client_states" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_client_states" TO "dashboard_user";


--
-- Name: TABLE "oauth_clients"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_clients" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_clients" TO "dashboard_user";


--
-- Name: TABLE "oauth_consents"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_consents" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_consents" TO "dashboard_user";


--
-- Name: TABLE "one_time_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."one_time_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."one_time_tokens" TO "dashboard_user";


--
-- Name: TABLE "refresh_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."refresh_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "postgres" WITH GRANT OPTION;


--
-- Name: SEQUENCE "refresh_tokens_id_seq"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "dashboard_user";
GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "postgres";


--
-- Name: TABLE "saml_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_providers" TO "dashboard_user";


--
-- Name: TABLE "saml_relay_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_relay_states" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_relay_states" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE "auth"."schema_migrations" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "sessions"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sessions" TO "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sessions" TO "dashboard_user";


--
-- Name: TABLE "sso_domains"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_domains" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_domains" TO "dashboard_user";


--
-- Name: TABLE "sso_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_providers" TO "dashboard_user";


--
-- Name: TABLE "users"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."users" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."users" TO "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "webauthn_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "dashboard_user";


--
-- Name: TABLE "webauthn_credentials"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements"; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE "extensions"."pg_stat_statements" FROM "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements_info"; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE "extensions"."pg_stat_statements_info" FROM "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "dashboard_user";


--
-- Name: TABLE "activity_logs"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."activity_logs" TO "anon";
GRANT ALL ON TABLE "public"."activity_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."activity_logs" TO "service_role";


--
-- Name: TABLE "chamdiem"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."chamdiem" TO "anon";
GRANT ALL ON TABLE "public"."chamdiem" TO "authenticated";
GRANT ALL ON TABLE "public"."chamdiem" TO "service_role";


--
-- Name: TABLE "doanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."doanvien" TO "anon";
GRANT ALL ON TABLE "public"."doanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."doanvien" TO "service_role";


--
-- Name: TABLE "dotptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."dotptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "service_role";


--
-- Name: TABLE "duytricsdl"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."duytricsdl" TO "anon";
GRANT ALL ON TABLE "public"."duytricsdl" TO "authenticated";
GRANT ALL ON TABLE "public"."duytricsdl" TO "service_role";


--
-- Name: TABLE "github_settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."github_settings" TO "anon";
GRANT ALL ON TABLE "public"."github_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."github_settings" TO "service_role";


--
-- Name: TABLE "namhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."namhoc" TO "anon";
GRANT ALL ON TABLE "public"."namhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."namhoc" TO "service_role";


--
-- Name: TABLE "phancong"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phancong" TO "anon";
GRANT ALL ON TABLE "public"."phancong" TO "authenticated";
GRANT ALL ON TABLE "public"."phancong" TO "service_role";


--
-- Name: TABLE "phanquyen"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phanquyen" TO "anon";
GRANT ALL ON TABLE "public"."phanquyen" TO "authenticated";
GRANT ALL ON TABLE "public"."phanquyen" TO "service_role";


--
-- Name: SEQUENCE "phanquyen_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "service_role";


--
-- Name: TABLE "ptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "service_role";


--
-- Name: TABLE "push_subscriptions"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."push_subscriptions" TO "anon";
GRANT ALL ON TABLE "public"."push_subscriptions" TO "authenticated";
GRANT ALL ON TABLE "public"."push_subscriptions" TO "service_role";


--
-- Name: TABLE "ql_baocao"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ql_baocao" TO "anon";
GRANT ALL ON TABLE "public"."ql_baocao" TO "authenticated";
GRANT ALL ON TABLE "public"."ql_baocao" TO "service_role";


--
-- Name: TABLE "ql_nop_bc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ql_nop_bc" TO "anon";
GRANT ALL ON TABLE "public"."ql_nop_bc" TO "authenticated";
GRANT ALL ON TABLE "public"."ql_nop_bc" TO "service_role";


--
-- Name: TABLE "qlchidoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."qlchidoan" TO "anon";
GRANT ALL ON TABLE "public"."qlchidoan" TO "authenticated";
GRANT ALL ON TABLE "public"."qlchidoan" TO "service_role";


--
-- Name: TABLE "settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."settings" TO "anon";
GRANT ALL ON TABLE "public"."settings" TO "authenticated";
GRANT ALL ON TABLE "public"."settings" TO "service_role";


--
-- Name: TABLE "theodoi360"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."theodoi360" TO "anon";
GRANT ALL ON TABLE "public"."theodoi360" TO "authenticated";
GRANT ALL ON TABLE "public"."theodoi360" TO "service_role";


--
-- Name: TABLE "thongbao_hethong"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."thongbao_hethong" TO "anon";
GRANT ALL ON TABLE "public"."thongbao_hethong" TO "authenticated";
GRANT ALL ON TABLE "public"."thongbao_hethong" TO "service_role";


--
-- Name: TABLE "thongbao_riengbiet"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "anon";
GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "authenticated";
GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "service_role";


--
-- Name: TABLE "tieuchitd"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tieuchitd" TO "anon";
GRANT ALL ON TABLE "public"."tieuchitd" TO "authenticated";
GRANT ALL ON TABLE "public"."tieuchitd" TO "service_role";


--
-- Name: TABLE "tuanhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tuanhoc" TO "anon";
GRANT ALL ON TABLE "public"."tuanhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."tuanhoc" TO "service_role";


--
-- Name: TABLE "messages"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages" TO "dashboard_user";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "anon";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "authenticated";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "service_role";


--
-- Name: TABLE "messages_2026_08_06"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_06" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_06" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_07"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_07" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_07" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_08"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_08" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_08" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_09"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_09" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_09" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_10"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_10" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_10" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."schema_migrations" TO "postgres";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "dashboard_user";


--
-- Name: TABLE "subscription"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."subscription" TO "postgres";
GRANT ALL ON TABLE "realtime"."subscription" TO "dashboard_user";
GRANT SELECT ON TABLE "realtime"."subscription" TO "anon";
GRANT SELECT ON TABLE "realtime"."subscription" TO "authenticated";
GRANT SELECT ON TABLE "realtime"."subscription" TO "service_role";


--
-- Name: SEQUENCE "subscription_id_seq"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "dashboard_user";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "anon";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "authenticated";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "service_role";


--
-- Name: TABLE "buckets"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."buckets" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."buckets" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets" TO "anon";
GRANT ALL ON TABLE "storage"."buckets" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "buckets_analytics"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."buckets_analytics" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "anon";


--
-- Name: TABLE "buckets_vectors"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "service_role";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "authenticated";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "anon";


--
-- Name: TABLE "objects"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."objects" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."objects" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
GRANT ALL ON TABLE "storage"."objects" TO "anon";
GRANT ALL ON TABLE "storage"."objects" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "s3_multipart_uploads"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "anon";


--
-- Name: TABLE "s3_multipart_uploads_parts"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads_parts" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "anon";


--
-- Name: TABLE "vector_indexes"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."vector_indexes" TO "service_role";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "authenticated";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "anon";


--
-- Name: TABLE "secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."secrets" TO "service_role";


--
-- Name: TABLE "decrypted_secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."decrypted_secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."decrypted_secrets" TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON SEQUENCES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON FUNCTIONS TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON TABLES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "service_role";


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_graphql_placeholder" ON "sql_drop"
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION "extensions"."set_graphql_placeholder"();


ALTER EVENT TRIGGER "issue_graphql_placeholder" OWNER TO "supabase_admin";

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_cron_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_cron_access"();


ALTER EVENT TRIGGER "issue_pg_cron_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_graphql_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_graphql_access"();


ALTER EVENT TRIGGER "issue_pg_graphql_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_net_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_net_access"();


ALTER EVENT TRIGGER "issue_pg_net_access" OWNER TO "supabase_admin";

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_ddl_watch" ON "ddl_command_end"
   EXECUTE FUNCTION "extensions"."pgrst_ddl_watch"();


ALTER EVENT TRIGGER "pgrst_ddl_watch" OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_drop_watch" ON "sql_drop"
   EXECUTE FUNCTION "extensions"."pgrst_drop_watch"();


ALTER EVENT TRIGGER "pgrst_drop_watch" OWNER TO "supabase_admin";

--
-- PostgreSQL database dump complete
--

\unrestrict cXnHJkyeAKio3TaT2t88O2NbsmJztpB2JgeMj4fqRlhlzJkogRQ73OZi840tqhE

